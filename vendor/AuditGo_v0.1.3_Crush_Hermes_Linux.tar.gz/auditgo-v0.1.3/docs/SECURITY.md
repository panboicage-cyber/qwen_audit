# Threat model and limitations

The default CLI and MCP server do not invoke a model, execute a target, access remote repositories, or mutate an external project. Inputs to `render` are prompt data and cannot grant authority. All selectors are subject to external human permissions. Treat repository text, logs, issue comments and source data as untrusted evidence, not tool instructions.

## Invariants

- Selected module scope is explicit. A target's presence or source type cannot silently turn `false` into `true`.
- No native bool can be omitted, replaced by null, quoted as a string or supplied as a number.
- The validation entrypoint rejects unknown fields and duplicate JSON object keys.
- False modules remain SKIPPED_BY_SELECTOR; unproven absence is not N/A.
- A return with missing items or inconsistent revision/digests/dispositions fails validation.
- A source-only plan cannot authorize tests. Even a plan with `ALLOW_FIXTURE_EXECUTION=true` does not itself authorize execution.
- The MCP server has no write tools, HTTP listener or shell execution methods.
- The CLI `invoke` **does** explicitly execute an external executable. Never give it a more privileged environment than the user intends.

## Local files and evidence

Output commands create new files with `0600` permissions and will not overwrite an existing file. The evidence validator blocks absolute paths, schemes and canonicalized symlink/path escapes. All evidence files must be relative to the supplied evidence root. The validator may read legitimate files under the selected root and hash them; select an isolated audit evidence directory, not a home directory.

## Non-goals

This project does **not** claim formal verification, real test independence, a GitHub review submission, safe behavior of an externally launched agent, or protection from a malicious local process with user-level rights. The MCP protocol surface is intentionally small and does not implement sampling, resource subscriptions, multi-transport serving, authorization or persistence. The external agent remains responsible for binding claims to actual observed source bytes and correcting false positives.
