# Crush / Hermes MCP selector recovery — AuditGo v0.1.2

## Cause
AuditGo v0.1.1 exposed `audit_plan(config_json)` but did not advertise the exact nested selector object in tool metadata. The underlying schema requires **nine** audit types, **twelve** module switches and **four** control switches as native JSON booleans. `RUNTIME_CONCURRENCY` is an **audit type**, not a module. Guessing until errors stop is not a valid integration strategy.

## Fixed workflow

1. Call `audit_modules` only if you need to discover options.
2. Call `audit_config` with *typed* arguments:
   - `target_id`: an actual target name
   - `claim`: a specific claim to test
   - `audit_types`: list drawn from its enum (e.g. `IMPLEMENTATION`, `RUNTIME_CONCURRENCY`)
   - `modules`: domain inventories (e.g. `GO_NATIVE_BINARY`)
   - `source_revision`: exact commit if known (optional)
3. Take the full JSON text returned by `audit_config`, unchanged, and supply it as the **string** parameter `config_json` to `audit_plan`.
4. Call `audit_render` with the same string if a mission prompt is needed.
5. Treat `AUDITED` as **selected**, not completed. AuditGo does not perform inspection, run tests, or grant permissions.

### Copy/paste instruction for Crush or Hermes

> Stop guessing selector keys. Call the AuditGo MCP tool `audit_config` to construct the complete selector object. For a Go implementation/concurrency review, request `audit_types` `["IMPLEMENTATION","RUNTIME_CONCURRENCY"]`, `modules` `["GO_NATIVE_BINARY"]`, and an actual target ID and claim. Pass the returned JSON verbatim as the `config_json` string to `audit_plan`, then to `audit_render`. If `audit_config` is unavailable, stop and report a stale AuditGo MCP server instead of retrying malformed JSON. Do not run tests, edit files, or claim an audit occurred unless separately authorized.

## Installing updated binary

Replace the `auditgo-v0.1.1` path in the `mcp add auditgo` command in `~/.config/crush/crushrc` with the absolute path to the v0.1.2 Linux binary, then restart Crush. If Hermes uses an explicit `tools.include` list, insert `audit_config` alongside the other AuditGo tools before `/reload-mcp`.

This update only fixes config construction and discovery. The audit registry hash remains unchanged.
