# AuditGo closeout: short human status + precise machine receipt (v0.1.3)

**Purpose:** produce returns similar in form to an operational repair receipt:
(1) short prose saying what is supported, what was actually verified and what
remains pending, followed by (2) detailed JSON preserving evidence identity,
verified checks, *reported* executions/changes, blockers, limits and next gates.

The existing `auditgo-return.v1` per-item ledger remains canonical. Closeout is
**not** a new source of truth and never upgrades `EVIDENCE_INCOMPLETE` to PASS.

## CLI usage

```bash
# A validated, evidence-populated return is required (seed alone remains unassessed).
auditgo validate -config audit.json -report audit_independent_return.json

auditgo closeout \
  -config audit.json \
  -report audit_independent_return.json \
  -out-dir ./closeout-001

# To separately check evidence file bytes referenced by the report:
auditgo closeout \
  -config audit.json \
  -report audit_independent_return.json \
  -evidence-root ./audit-evidence \
  -out-dir ./closeout-002

# Optional, externally attested execution history and unchanged boundaries:
auditgo closeout \
  -config audit.json -report audit_independent_return.json \
  -supplement ./closeout-supplement.json \
  -out-dir ./closeout-003

(cd closeout-001 && sha256sum -c SHA256SUMS.txt)
```

The CLI creates a **new directory only**, writes files with private permissions,
refuses overwrites and prints the short narrative to stdout:

- `AUDIT_RESULT.md`: conversational operational summary, outcome and next gate.
- `audit-evidence-receipt.json`: `auditgo-evidence-receipt/v1` provenance,
  severity/count summary, blockers, optional activity, limitations and gates.
- `SHA256SUMS.txt`: SHA-256 checksums of the two generated files. The receipt
  cannot embed its own SHA-256 without circularity; use this sidecar or `sha256sum`.

**Evidence status semantics**: `NOT_CHECKED` means digest syntax only;
`VERIFIED_REFERENCED_BYTES` means all referenced local evidence bytes matched
under the supplied root; `NO_REFERENCED_EVIDENCE` means a root was given but
there were no file references to check. Source revision and assertions of
unchanged files or executed commands are not independently proved by closeout.

## Optional activity supplement

See [`../examples/closeout-supplement.example.json`](../examples/closeout-supplement.example.json).
Its schema is `auditgo-closeout-supplement/v1` and allows these fields:

- `scope`: explicit human-readable scope.
- `authorization`: `source`, `scope`, optional `reference` (a cited authorization,
  not a grant of authority).
- `reported_review`: `classification`, `reviewer`, `notes` — **not** an automatic
  independent approval.
- `changed_files`: `path`, exact `before_sha256`, `after_sha256`.
- `unchanged_dependencies`: `path`, exact `sha256`.
- `verification`: `command`, `cwd`, `exit_code` (integer or null), `result`,
  optional `output_evidence` (`path`, `sha256` for stored command logs).
- `boundaries`: actions/candidates/settings known to be left untouched **per
  external report**; the absence of changed-file entries is not proof of no changes.
- `limitations`, `next`: precise remaining evidence gaps and responsible gates.

No field is fabricated from an absent supplement. Optional supplement hashes,
commands, and assertions are *agent- or user-reported*. Even when command output
hashes match bytes, this does not prove that the described command was executed
or that a reviewer was independent. This is an intentional provenance boundary.

## MCP / Crush / Hermes

New tool: `audit_closeout` (seven MCP tools total).

1. `audit_config` creates strict selectors.
2. `audit_plan`, `audit_render` establish the work; the external agent inspects
   evidence and fills the complete audit return.
3. `audit_validate` checks the complete return, which may legitimately end in
   `EVIDENCE_INCOMPLETE`.
4. `audit_closeout(config_json, report_json[, supplement_json])` returns both
   `summary_markdown` and `receipt` in a JSON text tool response.

`audit_closeout` itself does not write files or verify local evidence bytes.
To persist and independently hash the receipt, use the CLI. For Hermes, regenerate
`setup -client hermes` to include `audit_closeout` in its allowlist. For Crush,
restart after pointing the unchanged `mcp add ... --args mcp` syntax at v0.1.3.

## Required assistant final style

Keep the user-facing response to **2–4 compact paragraphs** and a reference to
the machine receipt. Lead with the actual outcome in ordinary English. Then
state real verification actions and their proven or merely reported status.
Finally state unchanged boundaries, unresolved blockers and the next approval
or review gate. Avoid checklist dumps, empty success claims, or bare JSON unless
explicitly requested. Never call a structurally valid report a passing audit.
