# Architecture and deterministic boundaries

## Components

1. **Embedded registry** (`internal/audit/data/registry.json`) is a fixed inventory derived from the user's unified master. `CORE` has 24 checks. Other domain inventories total 359; `CROSS_MODULE_COMPOUND` has no own checklist items.
2. **Data-only extension packs** augment the module inventory. Packs cannot change existing modules or duplicate any existing item ID; any pack changes the registry digest.
3. **Selector JSON** uses closed keys, strict native booleans, and duplicate-key detection. No YAML parser, coercion, automatic module discovery or silent module activation.
4. **Plan** is computed entirely from config+registry; map order does not affect serialized JSON or generated prompt. `AUDITED` is a coverage obligation, not an observed pass.
5. **Renderer** emits only CORE and selected `AUDITED` module obligations plus a manifest of the other module states; all prompt text is reproducible from the exact config+registry.
6. **Seed** creates a complete item inventory with explicit BLOCKED placeholders, never a presumed pass.
7. **Validator** reconciles returned items and claimed disposition, optionally recomputes evidence SHA-256 from local files under a bounded root.
8. **MCP** is JSON-RPC 2.0 line-delimited stdio with tool discovery and four read-only content transformations plus module listing. No persistence, hidden network listener or dynamic library loading.

## Decision table

For each domain module, in precedence order:

- selector `false` => `SKIPPED_BY_SELECTOR`.
- selector `true` and explicitly excluded with reason => `OUT_OF_SCOPE`.
- selector `true` and owner asserts ABSENT with referenced evidence => `NOT_APPLICABLE` (auditor must actually check this evidence).
- otherwise => `AUDITED`; missing source or blocked runtime is not proof of absence.

If compound is selected but fewer than two distinct domains are AUDITED, it resolves to NOT_APPLICABLE. Item counts include CORE and AUDITED domain inventories only. All 383 items stay represented in the JSON ledger; the others retain their selected module state.

## Disposition rule

Strongest surviving supported evidence wins: BLOCKER => CORE_INVARIANT_FAILURE; HIGH/CRITICAL => HARDENING_REQUIRED; supported overclaim => ARCHITECTURE_SOUND_CONTRACT_OVERCLAIMED; actionable LOW/MEDIUM => PASS_WITH_HARDENING; otherwise PASS. Incomplete or missing evidence does not create a HIGH severity finding. If completeness is EVIDENCE_INCOMPLETE, the final outcome is EVIDENCE_INCOMPLETE even when the provisional risk is PASS.

## Source revision and hash scope

`config_sha256` hashes the normalized serialized selector structure (not textual whitespace of the original file). `registry_sha256` hashes the normalized complete registry and all included extension packs in order. For reproducible audits retain the original selector, pack files, and rendered prompt. Evidence SHA-256 hashes are of file bytes and are verified locally only when requested with `-evidence-root`.
