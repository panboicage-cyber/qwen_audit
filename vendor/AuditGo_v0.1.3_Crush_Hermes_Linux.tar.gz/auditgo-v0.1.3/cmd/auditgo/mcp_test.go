package main

import (
	"bytes"
	"encoding/json"
	"strings"
	"testing"

	"auditgo/internal/audit"
)

func TestMCPHandshake(t *testing.T) {
	r, e := audit.DefaultRegistry()
	if e != nil {
		t.Fatal(e)
	}
	in := strings.NewReader("{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"initialize\",\"params\":{\"protocolVersion\":\"2025-06-18\"}}\n" + "{\"jsonrpc\":\"2.0\",\"id\":2,\"method\":\"tools/list\"}\n")
	var out bytes.Buffer
	if e := serveMCP(in, &out, r); e != nil {
		t.Fatal(e)
	}
	lines := strings.Split(strings.TrimSpace(out.String()), "\n")
	if len(lines) != 2 {
		t.Fatalf("responses=%s", out.String())
	}
	for _, line := range lines {
		if !json.Valid([]byte(line)) {
			t.Fatalf("invalid JSON-RPC %s", line)
		}
	}
	if !strings.Contains(lines[1], "audit_render") || !strings.Contains(lines[1], "audit_config") || !strings.Contains(lines[1], "audit_validate") {
		t.Fatal("missing MCP tools")
	}
}
func TestMCPPlanAndUnknownTool(t *testing.T) {
	r, e := audit.DefaultRegistry()
	if e != nil {
		t.Fatal(e)
	}
	c := audit.DefaultConfig(r)
	c.Target.ID = "test"
	c.Target.Claims = []string{"must remain safe"}
	b, _ := json.Marshal(string(audit.JSON(c)))
	result, err := callTool("audit_plan", map[string]json.RawMessage{"config_json": b}, r)
	if err != nil || !strings.Contains(result, "auditgo-plan.v1") {
		t.Fatalf("invalid plan %v %s", err, result)
	}
	if _, err := callTool("tool_that_writes_files", nil, r); err == nil {
		t.Fatal("unexpected command allowed")
	}
}
