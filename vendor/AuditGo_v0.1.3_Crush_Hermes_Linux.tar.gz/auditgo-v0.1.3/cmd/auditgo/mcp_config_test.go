package main

import (
	"encoding/json"
	"strings"
	"testing"

	"auditgo/internal/audit"
)

func configArgs(t *testing.T, v any) map[string]json.RawMessage {
	t.Helper()
	raw, err := json.Marshal(v)
	if err != nil {
		t.Fatal(err)
	}
	var args map[string]json.RawMessage
	if err := json.Unmarshal(raw, &args); err != nil {
		t.Fatal(err)
	}
	return args
}

func TestAuditConfigConstructsCompleteSelectors(t *testing.T) {
	r, err := audit.DefaultRegistry()
	if err != nil {
		t.Fatal(err)
	}
	args := configArgs(t, map[string]any{
		"target_id": "local-Go-repo", "claim": "Does not leak goroutines",
		"audit_types": []string{"IMPLEMENTATION", "RUNTIME_CONCURRENCY"},
		"modules":     []string{"GO_NATIVE_BINARY"},
	})
	result, err := callTool("audit_config", args, r)
	if err != nil {
		t.Fatal(err)
	}
	c, err := audit.ParseConfig([]byte(result), r)
	if err != nil {
		t.Fatal(err)
	}
	if len(c.Selectors.AuditTypes) != 9 || len(c.Selectors.Modules) != len(r.Modules) || len(c.Selectors.Controls) != 4 {
		t.Fatal("missing strict switch keys")
	}
	if !c.Selectors.AuditTypes["RUNTIME_CONCURRENCY"] || c.Selectors.AuditTypes["DESIGN_CONTRACT"] || !c.Selectors.Modules["GO_NATIVE_BINARY"] {
		t.Fatal("wrong switch selection")
	}
	if c.Selectors.Controls["ALLOW_FIXTURE_EXECUTION"] {
		t.Fatal("audit_config accidentally enabled execution")
	}
	// The returned config is directly acceptable by audit_plan, no hand-edited JSON.
	encoded, _ := json.Marshal(result)
	plan, err := callTool("audit_plan", map[string]json.RawMessage{"config_json": encoded}, r)
	if err != nil || !strings.Contains(plan, `"source_only": true`) {
		t.Fatalf("plan failed/unsafe %v %s", err, plan)
	}
}

func TestAuditConfigRejectsInvalidInputs(t *testing.T) {
	r, err := audit.DefaultRegistry()
	if err != nil {
		t.Fatal(err)
	}
	base := func() map[string]any {
		return map[string]any{"target_id": "good", "claim": "Claim", "audit_types": []string{"IMPLEMENTATION"}, "modules": []string{"GO_NATIVE_BINARY"}}
	}
	checks := []struct {
		name   string
		mutate func(map[string]any)
	}{
		{"missing target", func(m map[string]any) { delete(m, "target_id") }},
		{"missing type", func(m map[string]any) { delete(m, "audit_types") }},
		{"empty type", func(m map[string]any) { m["audit_types"] = []string{} }},
		{"not enum", func(m map[string]any) { m["audit_types"] = []string{"RUNTIME_CONCURRENT"} }},
		{"type as module", func(m map[string]any) { m["modules"] = []string{"RUNTIME_CONCURRENCY"} }},
		{"modules scalar", func(m map[string]any) { m["modules"] = "GO_NATIVE_BINARY" }},
		{"duplicate", func(m map[string]any) { m["audit_types"] = []string{"IMPLEMENTATION", "IMPLEMENTATION"} }},
		{"unexpected key", func(m map[string]any) { m["go_crazy"] = true }},
	}
	for _, tc := range checks {
		t.Run(tc.name, func(t *testing.T) {
			x := base()
			tc.mutate(x)
			if _, err := callTool("audit_config", configArgs(t, x), r); err == nil {
				t.Fatal("invalid audit_config input accepted")
			}
		})
	}
}

func TestAuditConfigDiscoverableTypedSchema(t *testing.T) {
	r, err := audit.DefaultRegistry()
	if err != nil {
		t.Fatal(err)
	}
	def := auditConfigToolDef(r)
	b, err := json.Marshal(def)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(b), `"enum"`) || !strings.Contains(string(b), "RUNTIME_CONCURRENCY") || !strings.Contains(string(b), "GO_NATIVE_BINARY") {
		t.Fatalf("expected discoverable enum options: %s", b)
	}
	if !strings.Contains(string(b), `"additionalProperties":false`) {
		t.Fatalf("unknown argument keys must be disabled")
	}
}
