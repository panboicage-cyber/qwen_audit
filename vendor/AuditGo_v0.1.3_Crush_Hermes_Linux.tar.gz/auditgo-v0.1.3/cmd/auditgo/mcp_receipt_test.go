package main

import (
	"encoding/json"
	"strings"
	"testing"

	"auditgo/internal/audit"
)

func TestMCPAuditCloseout(t *testing.T) {
	r, err := audit.DefaultRegistry()
	if err != nil {
		t.Fatal(err)
	}
	c := audit.DefaultConfig(r)
	c.Target.ID = "receipt-test"
	c.Target.Claims = []string{"must preserve evidence"}
	rep := audit.Seed(c, r)
	configString, _ := json.Marshal(string(audit.JSON(c)))
	reportString, _ := json.Marshal(string(audit.JSON(rep)))
	result, err := callTool("audit_closeout", map[string]json.RawMessage{"config_json": configString, "report_json": reportString}, r)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(result, "auditgo-evidence-receipt/v1") || !strings.Contains(result, "EVIDENCE_INCOMPLETE") {
		t.Fatalf("invalid MCP closeout: %s", result)
	}
	if _, err := callTool("audit_closeout", map[string]json.RawMessage{"config_json": configString, "report_json": reportString, "unexpected": json.RawMessage(`"x"`)}, r); err == nil {
		t.Fatal("accepted unknown closeout argument")
	}
	rep.FinalDisposition = "PASS"
	forged, _ := json.Marshal(string(audit.JSON(rep)))
	if _, err := callTool("audit_closeout", map[string]json.RawMessage{"config_json": configString, "report_json": forged}, r); err == nil {
		t.Fatal("accepted forged report")
	}
}
