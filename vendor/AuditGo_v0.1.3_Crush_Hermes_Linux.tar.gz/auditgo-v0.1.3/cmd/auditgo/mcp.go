package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"strings"

	"auditgo/internal/audit"
)

type rpcRequest struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id,omitempty"`
	Method  string          `json:"method"`
	Params  json.RawMessage `json:"params,omitempty"`
}
type rpcResponse struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id"`
	Result  any             `json:"result,omitempty"`
	Error   any             `json:"error,omitempty"`
}

func response(w io.Writer, id json.RawMessage, result, errObj any) error {
	b, err := json.Marshal(rpcResponse{"2.0", id, result, errObj})
	if err != nil {
		return err
	}
	_, err = fmt.Fprintln(w, string(b))
	return err
}
func rpcErr(code int, msg string) any { return map[string]any{"code": code, "message": msg} }
func textResult(s string, failed bool) any {
	return map[string]any{"content": []any{map[string]any{"type": "text", "text": s}}, "isError": failed}
}
func toolDef(name, desc string, required []string) any {
	props := map[string]any{}
	for _, key := range required {
		props[key] = map[string]any{"type": "string", "description": "JSON text (UTF-8), strict schema"}
	}
	if len(required) == 0 {
		props = map[string]any{}
	}
	return map[string]any{"name": name, "description": desc, "inputSchema": map[string]any{"type": "object", "properties": props, "required": required, "additionalProperties": false}}
}
func serveMCP(in io.Reader, out io.Writer, r audit.Registry) error {
	scan := bufio.NewScanner(in)
	scan.Buffer(make([]byte, 64*1024), 16*1024*1024)
	for scan.Scan() {
		line := bytes.TrimSpace(scan.Bytes())
		if len(line) == 0 {
			continue
		}
		var req rpcRequest
		if err := audit.StrictDecode(line, &req); err != nil {
			_ = response(out, json.RawMessage("null"), nil, rpcErr(-32700, "invalid JSON request"))
			continue
		}
		if req.JSONRPC != "2.0" {
			_ = response(out, req.ID, nil, rpcErr(-32600, "invalid JSON-RPC version"))
			continue
		}
		if len(req.ID) == 0 {
			continue
		} // notification
		switch req.Method {
		case "initialize":
			var p struct {
				ProtocolVersion string `json:"protocolVersion"`
			}
			_ = json.Unmarshal(req.Params, &p)
			pv := p.ProtocolVersion
			if pv == "" {
				pv = "2025-06-18"
			}
			_ = response(out, req.ID, map[string]any{"protocolVersion": pv, "capabilities": map[string]any{"tools": map[string]any{}}, "serverInfo": map[string]any{"name": "auditgo", "version": version}}, nil)
		case "ping":
			_ = response(out, req.ID, map[string]any{}, nil)
		case "tools/list":
			tools := []any{
				toolDef("audit_modules", "Discover all 9 exact audit types, all 12 module names, control keys, counts and registry hash. Never guess selector keys.", nil),
				auditConfigToolDef(r),
				toolDef("audit_plan", "Evaluate strict selectors and compute module states; does not audit. Pass config_json as the JSON string returned by audit_config (do NOT invent or omit selector keys).", []string{"config_json"}),
				toolDef("audit_render", "Render the audit mission. config_json MUST be complete JSON returned by audit_config or AuditGo CLI init.", []string{"config_json"}),
				toolDef("audit_seed", "Produce an explicitly UNASSESSED ledger with every registry item", []string{"config_json"}),
				toolDef("audit_validate", "Validate complete agent return claims against selector and registry", []string{"config_json", "report_json"}),
				auditCloseoutToolDef(),
			}
			_ = response(out, req.ID, map[string]any{"tools": tools}, nil)
		case "tools/call":
			var p struct {
				Name      string                     `json:"name"`
				Arguments map[string]json.RawMessage `json:"arguments"`
			}
			if err := json.Unmarshal(req.Params, &p); err != nil {
				_ = response(out, req.ID, nil, rpcErr(-32602, "invalid call parameters"))
				continue
			}
			answer, e := callTool(p.Name, p.Arguments, r)
			if e != nil {
				_ = response(out, req.ID, textResult(e.Error(), true), nil)
			} else {
				_ = response(out, req.ID, textResult(answer, false), nil)
			}
		default:
			_ = response(out, req.ID, nil, rpcErr(-32601, "unknown method"))
		}
	}
	return scan.Err()
}
func callTool(name string, args map[string]json.RawMessage, r audit.Registry) (string, error) {
	if name == "audit_modules" {
		if len(args) > 0 {
			return "", fmt.Errorf("audit_modules accepts no arguments")
		}
		var b strings.Builder
		fmt.Fprintf(&b, "AUDIT TYPES (%d, exact switches in selectors.audit_types): %s\n", len(audit.Types), strings.Join(audit.Types, ", "))
		fmt.Fprintf(&b, "CONTROLS (%d, exact switches in selectors.controls): %s\n", len(audit.Controls), strings.Join(audit.Controls, ", "))
		fmt.Fprintf(&b, "CORE: %d checks (always on)\n", count(r, "CORE"))
		for _, m := range r.Modules {
			fmt.Fprintf(&b, "%s: %d — %s\n", m.Name, count(r, m.Name), m.Description)
		}
		fmt.Fprintf(&b, "Registry SHA-256: %s", audit.Digest(audit.JSON(r)))
		return b.String(), nil
	}
	if name == "audit_config" {
		return createAuditConfig(args, r)
	}
	if name == "audit_closeout" {
		return createAuditCloseout(args, r)
	}
	allowed := map[string][]string{"audit_plan": {"config_json"}, "audit_render": {"config_json"}, "audit_seed": {"config_json"}, "audit_validate": {"config_json", "report_json"}}
	keys, ok := allowed[name]
	if !ok {
		return "", fmt.Errorf("unknown tool %q", name)
	}
	if len(args) != len(keys) {
		return "", fmt.Errorf("expected keys: %s", strings.Join(keys, ","))
	}
	values := map[string]string{}
	for _, key := range keys {
		raw, ok := args[key]
		if !ok {
			return "", fmt.Errorf("missing key %s", key)
		}
		var s string
		if err := json.Unmarshal(raw, &s); err != nil {
			return "", fmt.Errorf("%s must be JSON string", key)
		}
		values[key] = s
	}
	c, err := audit.ParseConfig([]byte(values["config_json"]), r)
	if err != nil {
		return "", fmt.Errorf("%w; use audit_config to generate all strict selector keys", err)
	}
	switch name {
	case "audit_plan":
		return string(audit.JSON(audit.BuildPlan(c, r))), nil
	case "audit_render":
		return audit.Render(c, r), nil
	case "audit_seed":
		return string(audit.JSON(audit.Seed(c, r))), nil
	case "audit_validate":
		rep, problems, err := audit.ValidateReportBytes([]byte(values["report_json"]), c, r)
		if err != nil {
			return "", err
		}
		return string(audit.JSON(map[string]any{"valid": len(problems) == 0, "problems": problems, "reported_outcome": audit.Summary(rep)})), nil
	}
	return "", fmt.Errorf("unknown tool")
}

// audit_closeout returns a short human summary and compact machine JSON receipt.
// It never writes files, performs tests, or independently verifies evidence bytes.
func auditCloseoutToolDef() any {
	return map[string]any{
		"name":        "audit_closeout",
		"description": "Produce a concise evidence-backed closeout summary and structured provenance receipt from a VALID auditgo-return.v1 ledger. MUST call after audit_validate. This is a transformation of agent-reported evidence, not independent replay. Optional typed supplement records externally reported verification commands, changed files, preserved boundaries and next gates.",
		"inputSchema": map[string]any{
			"type": "object",
			"properties": map[string]any{
				"config_json":     map[string]any{"type": "string", "description": "Complete selector JSON string from audit_config"},
				"report_json":     map[string]any{"type": "string", "description": "Complete evaluated return JSON string, not an UNASSESSED seed used as proof"},
				"supplement_json": map[string]any{"type": "string", "description": "Optional auditgo-closeout-supplement/v1 JSON string for user/agent-reported actions, changed hashes and preserved boundaries"},
			},
			"required":             []string{"config_json", "report_json"},
			"additionalProperties": false,
		},
	}
}
func createAuditCloseout(args map[string]json.RawMessage, r audit.Registry) (string, error) {
	if len(args) < 2 || len(args) > 3 {
		return "", fmt.Errorf("audit_closeout requires config_json and report_json; optional supplement_json")
	}
	vals := map[string]string{}
	for k, v := range args {
		if k != "config_json" && k != "report_json" && k != "supplement_json" {
			return "", fmt.Errorf("audit_closeout rejects key %s", k)
		}
		var parsed string
		if err := json.Unmarshal(v, &parsed); err != nil {
			return "", fmt.Errorf("audit_closeout %s must be JSON string", k)
		}
		vals[k] = parsed
	}
	if _, ok := vals["config_json"]; !ok {
		return "", fmt.Errorf("audit_closeout missing config_json")
	}
	if _, ok := vals["report_json"]; !ok {
		return "", fmt.Errorf("audit_closeout missing report_json")
	}
	c, err := audit.ParseConfig([]byte(vals["config_json"]), r)
	if err != nil {
		return "", err
	}
	raw := []byte(vals["report_json"])
	rep, problems, err := audit.ValidateReportBytes(raw, c, r)
	if err != nil {
		return "", err
	}
	if len(problems) != 0 {
		return "", fmt.Errorf("return invalid: %s", strings.Join(problems, "; "))
	}
	receipt, err := audit.BuildReceipt(c, r, rep, []byte(vals["config_json"]), raw, []byte(vals["supplement_json"]), "NOT_CHECKED")
	if err != nil {
		return "", err
	}
	return string(audit.JSON(map[string]any{"summary_markdown": audit.RenderReceipt(receipt), "receipt": receipt})), nil
}
