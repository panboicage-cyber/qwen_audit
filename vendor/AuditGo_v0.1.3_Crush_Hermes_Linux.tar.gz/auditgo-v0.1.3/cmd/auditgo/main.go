package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"

	"auditgo/internal/audit"
)

var version = "0.1.3"

type stringsFlag []string

func (f *stringsFlag) String() string     { return strings.Join(*f, ",") }
func (f *stringsFlag) Set(v string) error { *f = append(*f, v); return nil }
func abort(err error)                     { fmt.Fprintln(os.Stderr, "auditgo:", err); os.Exit(2) }
func output(path string, data []byte) error {
	if path == "" || path == "-" {
		_, e := os.Stdout.Write(data)
		return e
	}
	// Never replace an existing audit artifact silently.
	file, e := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		return e
	}
	if _, e = file.Write(data); e != nil {
		file.Close()
		os.Remove(path)
		return e
	}
	return file.Close()
}
func readConfig(path string, r audit.Registry) (audit.Config, error) {
	if path == "" {
		return audit.Config{}, errors.New("-config is required")
	}
	b, e := os.ReadFile(path)
	if e != nil {
		return audit.Config{}, e
	}
	return audit.ParseConfig(b, r)
}
func withRegistry(fs *flag.FlagSet) *stringsFlag {
	packs := new(stringsFlag)
	fs.Var(packs, "pack", "append extension pack JSON file (repeatable)")
	return packs
}
func parseCSV(args stringsFlag) []string {
	var out []string
	for _, x := range args {
		for _, v := range strings.Split(x, ",") {
			if strings.TrimSpace(v) != "" {
				out = append(out, strings.TrimSpace(v))
			}
		}
	}
	return out
}
func usage() {
	fmt.Print(`AuditGo v` + version + ` — portable adversarial prompt and audit ledger tool (pure Go)

Commands:
  init       Create strict JSON selectors; all domain modules false by default
  modules    List available domain inventories and checklist counts
  plan       Compute exact module states, item counts and capability limits
  render     Render a complete, selected audit mission prompt
  seed       Create an explicitly UNASSESSED return JSON ledger
  validate   Validate report coverage, digests, and claimed dispositions
  closeout   Produce a short status report plus JSON evidence receipt
  invoke     Explicitly pass rendered prompt on stdin to an external agent command
  mcp        Local read-only MCP stdio tools for agent harnesses
  setup      Print example MCP configuration (never modifies client files)
  doctor     Check local installation and built-in registry
  version    Show version

Examples:
  auditgo init -out audit.json -target repo-pr4 -claim 'Must reject malformed bytes' -type IMPLEMENTATION -module GO_NATIVE_BINARY
  auditgo plan -config audit.json
  auditgo render -config audit.json -out mission.md
  auditgo seed -config audit.json -out return.json
  auditgo validate -config audit.json -report return.json
  auditgo closeout -config audit.json -report return.json -out-dir ./audit-closeout
  auditgo mcp

Use -pack FILE on init/modules/plan/render/seed/validate/invoke/mcp to add modules.
Configuration is strict JSON, NOT YAML. No network access or test execution by default.
`)
}
func main() {
	if len(os.Args) < 2 {
		usage()
		return
	}
	var err error
	switch os.Args[1] {
	case "version":
		fmt.Println(version)
	case "help", "-h", "--help":
		usage()
	case "doctor":
		r, e := audit.DefaultRegistry()
		if e != nil {
			abort(e)
		}
		exe, _ := os.Executable()
		fmt.Printf("AuditGo %s\nOS/arch: %s/%s\nBinary: %s\nGo runtime: %s\nRegistry modules: %d\nRegistry items: %d\nRegistry SHA-256: %s\nMCP: local stdio (no network listener)\n", version, runtime.GOOS, runtime.GOARCH, exe, runtime.Version(), len(r.Modules), len(r.Items), audit.Digest(audit.JSON(r)))
	case "init":
		fs := flag.NewFlagSet("init", flag.ContinueOnError)
		out := fs.String("out", "-", "config JSON output path (existing files not overwritten)")
		target := fs.String("target", "", "target identifier")
		desc := fs.String("description", "", "target description")
		revision := fs.String("revision", "", "exact source commit/revision")
		surface := fs.String("authorized-surface", "", "explicit authorized testing surface (does not grant authority)")
		disposable := fs.String("disposable-environment", "", "identified disposable test environment")
		allowFixtures := fs.Bool("allow-fixtures", false, "enable candidate fixtures; still requires separate authorization")
		types := new(stringsFlag)
		mods := new(stringsFlag)
		claims := new(stringsFlag)
		artifacts := new(stringsFlag)
		prohibited := new(stringsFlag)
		fs.Var(types, "type", "audit type to enable (repeatable or comma-delimited); disables default DESIGN_CONTRACT when given")
		fs.Var(mods, "module", "module to enable (repeatable or comma-delimited)")
		fs.Var(claims, "claim", "verbatim claim (repeatable)")
		fs.Var(artifacts, "artifact", "evidence locator (repeatable)")
		fs.Var(prohibited, "prohibit", "explicit prohibited action (repeatable)")
		packs := withRegistry(fs)
		if err = fs.Parse(os.Args[2:]); err != nil {
			abort(err)
		}
		r, e := audit.LoadRegistry(*packs)
		if e != nil {
			abort(e)
		}
		c := audit.DefaultConfig(r)
		if *target != "" {
			c.Target.ID = *target
		}
		if *desc != "" {
			c.Target.Description = *desc
		}
		if len(*claims) > 0 {
			c.Target.Claims = *claims
		}
		if len(*artifacts) > 0 {
			c.Target.Artifacts = *artifacts
		}
		if len(*prohibited) > 0 {
			c.Target.ProhibitedActions = *prohibited
		}
		if *revision != "" {
			c.Target.SourceRevision = *revision
		}
		if *surface != "" {
			c.Target.AuthorizedTestSurface = *surface
		}
		if *disposable != "" {
			c.Target.DisposableEnvironment = *disposable
		}
		if *allowFixtures {
			c.Selectors.Controls["ALLOW_FIXTURE_EXECUTION"] = true
		}
		if len(*types) > 0 {
			for k := range c.Selectors.AuditTypes {
				c.Selectors.AuditTypes[k] = false
			}
			for _, t := range parseCSV(*types) {
				if _, ok := c.Selectors.AuditTypes[t]; !ok {
					abort(fmt.Errorf("unknown audit type %s", t))
				}
				c.Selectors.AuditTypes[t] = true
			}
		}
		for _, m := range parseCSV(*mods) {
			if _, ok := c.Selectors.Modules[m]; !ok {
				abort(fmt.Errorf("unknown module %s", m))
			}
			c.Selectors.Modules[m] = true
		}
		err = output(*out, audit.JSON(c))
	case "modules":
		fs := flag.NewFlagSet("modules", flag.ContinueOnError)
		packs := withRegistry(fs)
		if err = fs.Parse(os.Args[2:]); err != nil {
			abort(err)
		}
		r, e := audit.LoadRegistry(*packs)
		if e != nil {
			abort(e)
		}
		fmt.Printf("CORE (always on): %d checklist items\n", count(r, "CORE"))
		for _, m := range r.Modules {
			fmt.Printf("%-24s %3d  %s\n", m.Name, count(r, m.Name), m.Description)
		}
	case "plan", "render", "seed", "validate", "invoke", "closeout":
		sub := os.Args[1]
		fs := flag.NewFlagSet(sub, flag.ContinueOnError)
		cfg := fs.String("config", "", "selector JSON path")
		out := fs.String("out", "-", "output file path, - for stdout (no overwrite)")
		report := fs.String("report", "", "machine return JSON path (validate only)")
		evidenceRoot := fs.String("evidence-root", "", "verify actual local evidence bytes inside this directory (validate/closeout)")
		supplementPath := fs.String("supplement", "", "optional strictly typed operational supplement JSON (closeout only)")
		outDir := fs.String("out-dir", "./audit-closeout", "new directory for closeout artifacts (existing directory rejected)")
		packs := withRegistry(fs)
		if err = fs.Parse(os.Args[2:]); err != nil {
			abort(err)
		}
		r, e := audit.LoadRegistry(*packs)
		if e != nil {
			abort(e)
		}
		c, e := readConfig(*cfg, r)
		if e != nil {
			abort(e)
		}
		switch sub {
		case "plan":
			err = output(*out, audit.JSON(audit.BuildPlan(c, r)))
		case "render":
			err = output(*out, []byte(audit.Render(c, r)))
		case "seed":
			err = output(*out, audit.JSON(audit.Seed(c, r)))
		case "validate":
			if *report == "" {
				abort(errors.New("-report is required"))
			}
			rep, issues, e := audit.ReadAndValidateReport(*report, c, r)
			if e != nil {
				abort(e)
			}
			if *evidenceRoot != "" {
				issues = append(issues, audit.VerifyEvidence(rep, *evidenceRoot)...)
			}
			payload := struct {
				Valid    bool     `json:"valid"`
				Problems []string `json:"problems"`
				Summary  string   `json:"reported_outcome"`
			}{len(issues) == 0, issues, audit.Summary(rep)}
			if e := output(*out, audit.JSON(payload)); e != nil {
				abort(e)
			}
			if len(issues) > 0 {
				os.Exit(1)
			}
		case "closeout":
			if *report == "" {
				abort(errors.New("-report is required"))
			}
			configRaw, e := os.ReadFile(*cfg)
			if e != nil {
				abort(e)
			}
			reportRaw, e := os.ReadFile(*report)
			if e != nil {
				abort(e)
			}
			rep, issues, e := audit.ValidateReportBytes(reportRaw, c, r)
			if e != nil {
				abort(e)
			}
			if len(issues) != 0 {
				abort(fmt.Errorf("return structurally invalid: %s", strings.Join(issues, "; ")))
			}
			var supplementRaw []byte
			if *supplementPath != "" {
				supplementRaw, e = os.ReadFile(*supplementPath)
				if e != nil {
					abort(e)
				}
			}
			supplement, e := audit.ParseSupplement(supplementRaw)
			if e != nil {
				abort(e)
			}
			evidenceStatus := "NOT_CHECKED"
			if *evidenceRoot != "" {
				problems := audit.VerifyEvidence(rep, *evidenceRoot)
				problems = append(problems, audit.VerifySupplementEvidence(supplement, *evidenceRoot)...)
				if len(problems) > 0 {
					abort(fmt.Errorf("evidence byte verification failed: %s", strings.Join(problems, "; ")))
				}
				if audit.ReferencedEvidenceCount(rep, supplement) == 0 {
					evidenceStatus = "NO_REFERENCED_EVIDENCE"
				} else {
					evidenceStatus = "VERIFIED_REFERENCED_BYTES"
				}
			}
			receipt, e := audit.BuildReceipt(c, r, rep, configRaw, reportRaw, supplementRaw, evidenceStatus)
			if e != nil {
				abort(e)
			}
			if e := os.Mkdir(*outDir, 0700); e != nil {
				abort(e)
			}
			created := []string{}
			save := func(name string, bytes []byte) error {
				path := filepath.Join(*outDir, name)
				if err := output(path, bytes); err != nil {
					return err
				}
				created = append(created, path)
				return nil
			}
			fail := func(err error) {
				for _, path := range created {
					_ = os.Remove(path)
				}
				_ = os.Remove(*outDir)
				abort(err)
			}
			receiptBytes := audit.JSON(receipt)
			summaryBytes := []byte(audit.RenderReceipt(receipt))
			if e := save("audit-evidence-receipt.json", receiptBytes); e != nil {
				fail(e)
			}
			if e := save("AUDIT_RESULT.md", summaryBytes); e != nil {
				fail(e)
			}
			sums := fmt.Sprintf("%s  audit-evidence-receipt.json\n%s  AUDIT_RESULT.md\n", audit.Digest(receiptBytes), audit.Digest(summaryBytes))
			if e := save("SHA256SUMS.txt", []byte(sums)); e != nil {
				fail(e)
			}
			fmt.Print(audit.RenderReceipt(receipt))
			fmt.Printf("\nCloseout files created in %s\n", *outDir)
		case "invoke":
			args := fs.Args()
			if len(args) == 0 {
				abort(errors.New("invoke requires an explicit command after --; no default agent execution"))
			}
			cmd := exec.CommandContext(context.Background(), args[0], args[1:]...)
			cmd.Stdin = strings.NewReader(audit.Render(c, r))
			cmd.Stdout = os.Stdout
			cmd.Stderr = os.Stderr
			cmd.Env = os.Environ()
			err = cmd.Run()
		}
	case "mcp":
		fs := flag.NewFlagSet("mcp", flag.ContinueOnError)
		packs := withRegistry(fs)
		if err = fs.Parse(os.Args[2:]); err != nil {
			abort(err)
		}
		r, e := audit.LoadRegistry(*packs)
		if e != nil {
			abort(e)
		}
		err = serveMCP(os.Stdin, os.Stdout, r)
	case "setup":
		fs := flag.NewFlagSet("setup", flag.ContinueOnError)
		client := fs.String("client", "generic", "generic, opencode, crush, hermes")
		if err = fs.Parse(os.Args[2:]); err != nil {
			abort(err)
		}
		exe, e := os.Executable()
		if e != nil {
			abort(e)
		}
		conf, e := setupExample(*client, exe)
		if e != nil {
			abort(e)
		}
		fmt.Fprintln(os.Stderr, "Example only: merge into your existing client config; no client files were changed.")
		_, err = os.Stdout.Write(conf)
	default:
		usage()
		os.Exit(2)
	}
	if err != nil {
		if errors.Is(err, io.EOF) {
			return
		}
		abort(err)
	}
}
func count(r audit.Registry, module string) int {
	n := 0
	for _, i := range r.Items {
		if i.Module == module {
			n++
		}
	}
	return n
}

// Ensure the standard JSON package remains a dependency for the compiler in
// platforms that use the CLI without the MCP transport.
var _ = json.Valid
