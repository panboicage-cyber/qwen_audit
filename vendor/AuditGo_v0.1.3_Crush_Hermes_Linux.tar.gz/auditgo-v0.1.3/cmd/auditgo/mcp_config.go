package main

import (
	"encoding/json"
	"fmt"
	"sort"
	"strings"

	"auditgo/internal/audit"
)

// audit_config is a deliberately typed alternative to asking an LLM to reconstruct
// a complete strict boolean selector object from error messages. It never writes files.
func auditConfigToolDef(r audit.Registry) any {
	modules := make([]string, 0, len(r.Modules))
	for _, m := range r.Modules {
		modules = append(modules, m.Name)
	}
	sort.Strings(modules)
	return map[string]any{
		"name":        "audit_config",
		"description": "FIRST build a complete strict auditgo-selector.v1 JSON config from small typed inputs; returns full config_json to pass UNCHANGED as a STRING into audit_plan/audit_render/audit_seed. Do not manually add/drop selector keys. Read-only; no audit performed.",
		"inputSchema": map[string]any{
			"type": "object",
			"properties": map[string]any{
				"target_id":       map[string]any{"type": "string", "minLength": 1, "description": "Stable target identifier; use actual repository/PR or project ID"},
				"claim":           map[string]any{"type": "string", "minLength": 1, "description": "Verbatim claim to test/falsify"},
				"description":     map[string]any{"type": "string", "description": "Optional target description"},
				"source_revision": map[string]any{"type": "string", "description": "Exact commit/revision if known; otherwise omitted and provenance stays incomplete"},
				"audit_types":     map[string]any{"type": "array", "minItems": 1, "uniqueItems": true, "items": map[string]any{"type": "string", "enum": audit.Types}, "description": "Select one or more EXACT audit-type enum values, e.g. IMPLEMENTATION and RUNTIME_CONCURRENCY; all other switches are false"},
				"modules":         map[string]any{"type": "array", "uniqueItems": true, "items": map[string]any{"type": "string", "enum": modules}, "description": "Domain inventory module names, e.g. GO_NATIVE_BINARY; may be empty. RUNTIME_CONCURRENCY is NOT a module."},
			},
			"required":             []string{"target_id", "claim", "audit_types"},
			"additionalProperties": false,
		},
	}
}

type auditConfigRequest struct {
	TargetID       string   `json:"target_id"`
	Claim          string   `json:"claim"`
	Description    string   `json:"description,omitempty"`
	SourceRevision string   `json:"source_revision,omitempty"`
	AuditTypes     []string `json:"audit_types"`
	Modules        []string `json:"modules,omitempty"`
}

func createAuditConfig(args map[string]json.RawMessage, r audit.Registry) (string, error) {
	raw, err := json.Marshal(args)
	if err != nil {
		return "", fmt.Errorf("audit_config invalid arguments: %w", err)
	}
	var req auditConfigRequest
	if err := audit.StrictDecode(raw, &req); err != nil {
		return "", fmt.Errorf("audit_config expects target_id, claim, audit_types array, optional modules array: %w", err)
	}
	if strings.TrimSpace(req.TargetID) == "" || strings.HasPrefix(req.TargetID, "REPLACE_") {
		return "", fmt.Errorf("audit_config: target_id must be non-empty and real")
	}
	if strings.TrimSpace(req.Claim) == "" || strings.HasPrefix(req.Claim, "REPLACE_") {
		return "", fmt.Errorf("audit_config: claim must be non-empty and real")
	}
	if len(req.AuditTypes) == 0 {
		return "", fmt.Errorf("audit_config: audit_types must contain at least one of %s", strings.Join(audit.Types, ", "))
	}
	c := audit.DefaultConfig(r)
	c.Target.ID = req.TargetID
	c.Target.Claims = []string{req.Claim}
	c.Target.Description = "Audit target: " + req.TargetID
	if req.Description != "" {
		c.Target.Description = req.Description
	}
	if req.SourceRevision != "" {
		c.Target.SourceRevision = req.SourceRevision
	}
	for key := range c.Selectors.AuditTypes {
		c.Selectors.AuditTypes[key] = false
	}
	seenTypes := map[string]bool{}
	for _, t := range req.AuditTypes {
		if seenTypes[t] {
			return "", fmt.Errorf("audit_config: duplicate audit type %q", t)
		}
		seenTypes[t] = true
		if _, ok := c.Selectors.AuditTypes[t]; !ok {
			return "", fmt.Errorf("audit_config: unknown audit type %q (valid: %s)", t, strings.Join(audit.Types, ", "))
		}
		c.Selectors.AuditTypes[t] = true
	}
	seenModules := map[string]bool{}
	for _, m := range req.Modules {
		if seenModules[m] {
			return "", fmt.Errorf("audit_config: duplicate module %q", m)
		}
		seenModules[m] = true
		if _, ok := c.Selectors.Modules[m]; !ok {
			return "", fmt.Errorf("audit_config: unknown module %q; use audit_modules to list modules (RUNTIME_CONCURRENCY is an audit type)", m)
		}
		c.Selectors.Modules[m] = true
	}
	if err := audit.ValidateConfig(c, r); err != nil {
		return "", fmt.Errorf("audit_config produced invalid config: %w", err)
	}
	return string(audit.JSON(c)), nil
}
