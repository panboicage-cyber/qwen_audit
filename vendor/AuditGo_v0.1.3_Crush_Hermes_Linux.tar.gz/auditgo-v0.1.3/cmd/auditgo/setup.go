package main

import (
	"encoding/json"
	"fmt"
	"path/filepath"
	"strings"

	"auditgo/internal/audit"
)

// setupExample emits data for the client to review; it never installs or mutates
// an agent configuration. The executable path is an absolute path to this binary.
func setupExample(client, executable string) ([]byte, error) {
	exe, err := filepath.Abs(executable)
	if err != nil {
		return nil, err
	}
	switch client {
	case "opencode":
		return audit.JSON(map[string]any{"mcp": map[string]any{"auditgo": map[string]any{"type": "local", "command": []string{exe, "mcp"}, "enabled": true}}}), nil
	case "generic":
		return audit.JSON(map[string]any{"mcpServers": map[string]any{"auditgo": map[string]any{"command": exe, "args": []string{"mcp"}}}}), nil
	case "crush":
		// Modern Crush reads Bash-based ~/.config/crush/crushrc or .crushrc.
		// Shell-quote the path; a source checkout path is not trusted input.
		return []byte("# Merge this line into a trusted crushrc (e.g. ~/.config/crush/crushrc).\n" +
			"# Do not replace existing provider/model/permission configuration.\n" +
			"mcp add auditgo --type stdio --command " + shellQuote(exe) + " --args mcp\n"), nil
	case "hermes":
		// YAML 1.2 accepts JSON double-quoted scalars. This escapes " and \.
		scalar, _ := json.Marshal(exe)
		return []byte("# Merge the auditgo entry under mcp_servers in ~/.hermes/config.yaml.\n" +
			"# Do not add a second mcp_servers root if one already exists.\n" +
			"mcp_servers:\n" +
			"  auditgo:\n" +
			"    command: " + string(scalar) + "\n" +
			"    args: [\"mcp\"]\n" +
			"    enabled: true\n" +
			"    tools:\n" +
			"      include: [audit_modules, audit_config, audit_plan, audit_render, audit_seed, audit_validate, audit_closeout]\n" +
			"      resources: false\n" +
			"      prompts: false\n"), nil
	default:
		return nil, fmt.Errorf("unknown client %q: supported clients are generic, opencode, crush, hermes", client)
	}
}

// single-quote a literal argument for Crush's Bash configuration language.
func shellQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'"
}
