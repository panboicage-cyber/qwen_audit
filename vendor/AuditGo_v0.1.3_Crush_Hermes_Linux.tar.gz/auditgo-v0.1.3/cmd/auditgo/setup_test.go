package main

import (
	"encoding/json"
	"strings"
	"testing"
)

func TestSetupClients(t *testing.T) {
	for _, client := range []string{"opencode", "generic", "crush", "hermes"} {
		t.Run(client, func(t *testing.T) {
			b, err := setupExample(client, "/tmp/safe auditgo")
			if err != nil {
				t.Fatal(err)
			}
			output := string(b)
			if !strings.Contains(output, "/tmp/safe auditgo") {
				t.Fatalf("missing executable path: %s", output)
			}
			if !strings.Contains(output, "mcp") {
				t.Fatalf("missing mcp argument: %s", output)
			}
			if client == "opencode" || client == "generic" {
				var obj any
				if err := json.Unmarshal(b, &obj); err != nil {
					t.Fatalf("invalid JSON: %v", err)
				}
			}
			if client == "crush" && !strings.Contains(output, "mcp add auditgo --type stdio --command '") {
				t.Fatal("not a crushrc entry")
			}
			if client == "hermes" && (!strings.Contains(output, "mcp_servers:\n  auditgo:") || !strings.Contains(output, "audit_config")) {
				t.Fatal("Hermes YAML should include config-construction tool")
			}
		})
	}
}

func TestSetupRejectsQwenAndUnknown(t *testing.T) {
	for _, name := range []string{"qwen", "unknown"} {
		if _, err := setupExample(name, "/tmp/auditgo"); err == nil {
			t.Fatalf("client %s accepted", name)
		}
	}
}

func TestShellQuote(t *testing.T) {
	got := shellQuote("/some/has'quote $PATH;echo bad")
	expected := "'/some/has'\\''quote $PATH;echo bad'"
	if got != expected {
		t.Fatalf("quoting mismatch: got %q want %q", got, expected)
	}
}
