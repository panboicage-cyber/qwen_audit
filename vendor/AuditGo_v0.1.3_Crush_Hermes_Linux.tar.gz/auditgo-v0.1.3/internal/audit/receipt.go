package audit

import (
	"errors"
	"fmt"
	"sort"
	"strings"
)

// A closeout is a compact, source-bound rendering of an existing audit report.
// Its supplementary execution history is self-reported, NEVER an independent
// replay or an approval. The auditgo-return.v1 ledger remains canonical.
const (
	ReceiptSchema    = "auditgo-evidence-receipt/v1"
	SupplementSchema = "auditgo-closeout-supplement/v1"
)

type FileChange struct {
	Path         string `json:"path"`
	BeforeSHA256 string `json:"before_sha256"`
	AfterSHA256  string `json:"after_sha256"`
}
type FileIdentity struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
}
type CommandEvidence struct {
	Command        string    `json:"command"`
	CWD            string    `json:"cwd"`
	ExitCode       *int      `json:"exit_code"`
	Result         string    `json:"result"`
	OutputEvidence *Evidence `json:"output_evidence,omitempty"`
}
type AuthorizationRecord struct {
	Source    string `json:"source"`
	Scope     string `json:"scope"`
	Reference string `json:"reference,omitempty"`
}
type ReviewRecord struct {
	Classification string `json:"classification"`
	Reviewer       string `json:"reviewer,omitempty"`
	Notes          string `json:"notes,omitempty"`
}
type Supplement struct {
	SchemaVersion         string               `json:"schema_version"`
	Scope                 string               `json:"scope,omitempty"`
	Authorization         *AuthorizationRecord `json:"authorization,omitempty"`
	ReportedReview        *ReviewRecord        `json:"reported_review,omitempty"`
	ChangedFiles          []FileChange         `json:"changed_files,omitempty"`
	UnchangedDependencies []FileIdentity       `json:"unchanged_dependencies,omitempty"`
	Verification          []CommandEvidence    `json:"verification,omitempty"`
	Boundaries            []string             `json:"boundaries,omitempty"`
	Limitations           []string             `json:"limitations,omitempty"`
	Next                  []string             `json:"next,omitempty"`
}

type ReceiptProvenance struct {
	TargetID                   string `json:"target_id"`
	SourceRevision             string `json:"source_revision"`
	SourceRevisionVerification string `json:"source_revision_verification"`
	ConfigSHA256               string `json:"config_sha256"`
	RegistrySHA256             string `json:"registry_sha256"`
	ConfigInputSHA256          string `json:"config_input_sha256"`
	ReturnInputSHA256          string `json:"return_input_sha256"`
	SupplementInputSHA256      string `json:"supplement_input_sha256,omitempty"`
	EvidenceBytes              string `json:"evidence_bytes"`
}
type ReceiptCoverage struct {
	Selected         int `json:"selected"`
	Assessed         int `json:"assessed"`
	Blocked          int `json:"blocked"`
	MandatoryBlocked int `json:"mandatory_blocked"`
	NotApplicable    int `json:"not_applicable"`
	Skipped          int `json:"skipped"`
}
type ReceiptFinding struct {
	ID            string     `json:"id"`
	Severity      string     `json:"severity"`
	Title         string     `json:"title"`
	EvidenceLevel string     `json:"evidence_level"`
	Evidence      []Evidence `json:"evidence"`
}
type Receipt struct {
	SchemaVersion string            `json:"schema_version"`
	Status        string            `json:"status"`
	Scope         string            `json:"scope"`
	Provenance    ReceiptProvenance `json:"provenance"`
	Outcome       struct {
		AuditCompleteness                 string `json:"audit_completeness"`
		RiskDisposition                   string `json:"risk_disposition"`
		FinalDisposition                  string `json:"final_disposition"`
		ReportValidation                  string `json:"report_validation"`
		EvidenceVerification              string `json:"evidence_verification"`
		IndependentSpecialistsEstablished bool   `json:"independent_specialists_established"`
	} `json:"outcome"`
	Coverage              ReceiptCoverage      `json:"coverage"`
	Findings              []ReceiptFinding     `json:"findings"`
	Blockers              []string             `json:"blockers"`
	Authorization         *AuthorizationRecord `json:"authorization,omitempty"`
	ReportedReview        *ReviewRecord        `json:"reported_review,omitempty"`
	ChangedFiles          []FileChange         `json:"changed_files"`
	UnchangedDependencies []FileIdentity       `json:"unchanged_dependencies"`
	Verification          []CommandEvidence    `json:"verification"`
	Boundaries            []string             `json:"boundaries"`
	Limitations           []string             `json:"limitations"`
	Next                  []string             `json:"next"`
	Attestation           string               `json:"attestation"`
}

func ParseSupplement(raw []byte) (Supplement, error) {
	if len(raw) == 0 {
		return Supplement{}, nil
	}
	var s Supplement
	if err := StrictDecode(raw, &s); err != nil {
		return s, fmt.Errorf("supplement: %w", err)
	}
	if s.SchemaVersion != SupplementSchema {
		return s, fmt.Errorf("supplement schema: expected %s", SupplementSchema)
	}
	for _, f := range s.ChangedFiles {
		if strings.TrimSpace(f.Path) == "" || !validSHA(f.BeforeSHA256) || !validSHA(f.AfterSHA256) {
			return s, fmt.Errorf("supplement: changed_files require path and both exact SHA-256 values")
		}
	}
	for _, f := range s.UnchangedDependencies {
		if strings.TrimSpace(f.Path) == "" || !validSHA(f.SHA256) {
			return s, fmt.Errorf("supplement: unchanged_dependencies require path and SHA-256")
		}
	}
	for _, v := range s.Verification {
		if strings.TrimSpace(v.Command) == "" || strings.TrimSpace(v.Result) == "" {
			return s, errors.New("supplement: verification entries require command and result")
		}
		if v.OutputEvidence != nil && (v.OutputEvidence.Path == "" || !validSHA(v.OutputEvidence.SHA256)) {
			return s, errors.New("supplement: invalid verification output evidence")
		}
	}
	if s.Authorization != nil && (strings.TrimSpace(s.Authorization.Source) == "" || strings.TrimSpace(s.Authorization.Scope) == "") {
		return s, errors.New("supplement: authorization requires source and scope")
	}
	if s.ReportedReview != nil && strings.TrimSpace(s.ReportedReview.Classification) == "" {
		return s, errors.New("supplement: reported review requires classification")
	}
	return s, nil
}

// BuildReceipt fails closed for structurally invalid returns. EvidenceStatus
// must be NOT_CHECKED, VERIFIED_REFERENCED_BYTES, or NO_REFERENCED_EVIDENCE.
func BuildReceipt(c Config, r Registry, rep Report, configRaw, reportRaw, supplementRaw []byte, evidenceStatus string) (Receipt, error) {
	if evidenceStatus != "NOT_CHECKED" && evidenceStatus != "VERIFIED_REFERENCED_BYTES" && evidenceStatus != "NO_REFERENCED_EVIDENCE" {
		return Receipt{}, errors.New("invalid evidence status")
	}
	if parsed, issues, err := ValidateReportBytes(reportRaw, c, r); err != nil {
		return Receipt{}, err
	} else if len(issues) != 0 {
		return Receipt{}, fmt.Errorf("report validation failed (%d problems): %s", len(issues), strings.Join(issues, "; "))
	} else {
		rep = parsed // bind receipt fields to the exact validated return bytes, never to an unvalidated in-memory argument
	}
	supp, err := ParseSupplement(supplementRaw)
	if err != nil {
		return Receipt{}, err
	}
	p := BuildPlan(c, r)
	o := Receipt{SchemaVersion: ReceiptSchema, Status: rep.FinalDisposition, Scope: c.Target.Description,
		Provenance: ReceiptProvenance{TargetID: rep.TargetID, SourceRevision: rep.SourceRevision,
			SourceRevisionVerification: "DECLARED_ONLY", ConfigSHA256: p.ConfigSHA256,
			RegistrySHA256: p.RegistrySHA256, ConfigInputSHA256: Digest(configRaw),
			ReturnInputSHA256: Digest(reportRaw), EvidenceBytes: evidenceStatus},
		Findings: []ReceiptFinding{}, Blockers: append([]string{}, rep.Blockers...),
		ChangedFiles:          append([]FileChange{}, supp.ChangedFiles...),
		UnchangedDependencies: append([]FileIdentity{}, supp.UnchangedDependencies...),
		Verification:          append([]CommandEvidence{}, supp.Verification...),
		Boundaries:            append([]string{}, supp.Boundaries...),
		Limitations:           append([]string{}, supp.Limitations...), Next: append([]string{}, supp.Next...),
		Authorization: supp.Authorization, ReportedReview: supp.ReportedReview,
		Attestation: "This receipt transforms a structurally valid, agent-supplied audit return. Test executions, changed-file before/after hashes, authorizations and independent review are reported claims, not independently replayed or granted by AuditGo. Hash matching proves bytes, not correctness or approval."}
	if len(supplementRaw) > 0 {
		o.Provenance.SupplementInputSHA256 = Digest(supplementRaw)
	}
	if supp.Scope != "" {
		o.Scope = supp.Scope
	}
	o.Outcome.AuditCompleteness = rep.AuditCompleteness
	o.Outcome.RiskDisposition = rep.RiskDisposition
	o.Outcome.FinalDisposition = rep.FinalDisposition
	o.Outcome.ReportValidation = "STRUCTURALLY_VALID"
	o.Outcome.EvidenceVerification = evidenceStatus
	o.Outcome.IndependentSpecialistsEstablished = rep.IndependentSpecialistsEstablished
	mandatory := make(map[string]bool, len(r.Items))
	for _, item := range r.Items {
		if item.Mandatory {
			mandatory[item.ID] = true
		}
	}
	for _, v := range rep.Items {
		switch v.Status {
		case "RUN", "ANALYZED", "NOT_APPLICABLE":
			o.Coverage.Assessed++
		case "BLOCKED":
			o.Coverage.Blocked++
			if mandatory[v.ItemID] {
				o.Coverage.MandatoryBlocked++
			}
		case "SKIPPED_BY_SELECTOR", "OUT_OF_SCOPE":
			o.Coverage.Skipped++
		}
		if v.Status == "NOT_APPLICABLE" {
			o.Coverage.NotApplicable++
		}
	}
	o.Coverage.Selected = p.SelectedItems
	for _, f := range rep.Findings {
		o.Findings = append(o.Findings, ReceiptFinding{ID: f.ID, Severity: f.Severity, Title: f.Title, EvidenceLevel: f.EvidenceLevel, Evidence: append([]Evidence{}, f.Evidence...)})
	}
	sort.Slice(o.Findings, func(i, j int) bool { return o.Findings[i].ID < o.Findings[j].ID })
	if rep.FinalDisposition == "EVIDENCE_INCOMPLETE" {
		o.Limitations = append(o.Limitations, "Audit remains EVIDENCE_INCOMPLETE; provisional technical risk is not a passing final disposition")
		if len(o.Next) == 0 {
			o.Next = append(o.Next, "Resolve blocked checks and missing provenance; repeat independent review before any acceptance")
		}
	}
	if evidenceStatus == "NOT_CHECKED" {
		o.Limitations = append(o.Limitations, "Evidence paths and SHA-256 values were structurally checked only; no local evidence bytes were read")
	}
	if evidenceStatus == "NO_REFERENCED_EVIDENCE" {
		o.Limitations = append(o.Limitations, "Evidence root was supplied but the return contains no referenced evidence files to verify")
	}
	if !provided(rep.SourceRevision) {
		o.Limitations = append(o.Limitations, "Exact source revision is not provided")
	}
	return o, nil
}

// RenderReceipt renders the concise, conversational head of an operational
// receipt. The full ledger and exact sourced evidence are kept in JSON.
func RenderReceipt(o Receipt) string {
	var b strings.Builder
	if len(o.Findings) > 0 {
		grouped := map[string]int{}
		for _, f := range o.Findings {
			grouped[f.Severity]++
		}
		labels := []string{}
		for _, s := range []string{"BLOCKER", "CRITICAL", "HIGH", "MEDIUM", "LOW"} {
			if grouped[s] > 0 {
				labels = append(labels, fmt.Sprintf("%d %s", grouped[s], s))
			}
		}
		fmt.Fprintf(&b, "%s: source audit reported %s findings. ", o.Provenance.TargetID, strings.Join(labels, ", "))
	} else {
		fmt.Fprintf(&b, "%s: source audit reported no surviving findings. ", o.Provenance.TargetID)
	}
	fmt.Fprintf(&b, "%d of %d selected checks are marked assessed, with %d blocked (%d mandatory).\n\n", o.Coverage.Assessed, o.Coverage.Selected, o.Coverage.Blocked, o.Coverage.MandatoryBlocked)
	if o.Outcome.AuditCompleteness == "EVIDENCE_INCOMPLETE" {
		fmt.Fprintf(&b, "Provisional technical risk classification (NOT a pass): %s. Final disposition: %s. ", o.Outcome.RiskDisposition, o.Outcome.FinalDisposition)
	} else {
		fmt.Fprintf(&b, "Technical risk: %s. Final disposition: %s. ", o.Outcome.RiskDisposition, o.Outcome.FinalDisposition)
	}
	if o.Outcome.FinalDisposition == "EVIDENCE_INCOMPLETE" {
		b.WriteString("The provisional risk judgment is not final acceptance. ")
	}
	fmt.Fprintf(&b, "The return passed structural validation; evidence bytes: %s.\n\n", o.Outcome.EvidenceVerification)
	if len(o.Verification) > 0 {
		fmt.Fprintf(&b, "Supplement reports %d verification commands", len(o.Verification))
		if len(o.ChangedFiles) > 0 {
			fmt.Fprintf(&b, " and %d changed files", len(o.ChangedFiles))
		}
		b.WriteString(". These are externally reported results, not tests executed by AuditGo.\n\n")
	} else if len(o.ChangedFiles) > 0 {
		fmt.Fprintf(&b, "Supplement reports %d changed files; before/after hashes are unverified external claims.\n\n", len(o.ChangedFiles))
	}
	if len(o.Blockers) > 0 {
		fmt.Fprintf(&b, "Open blockers: %s.\n\n", strings.Join(o.Blockers, "; "))
	}
	if len(o.Boundaries) > 0 {
		fmt.Fprintf(&b, "Preserved boundaries (reported): %s.\n\n", strings.Join(o.Boundaries, "; "))
	}
	if len(o.Next) > 0 {
		fmt.Fprintf(&b, "Next gate: %s.\n\n", strings.Join(o.Next, "; "))
	}
	fmt.Fprintf(&b, "Evidence receipt: `audit-evidence-receipt.json`\nSHA-256: `%s`\nUnderlying audit return SHA-256: `%s`\n", Digest(JSON(o)), o.Provenance.ReturnInputSHA256)
	return b.String()
}

// VerifySupplementEvidence verifies only the optional attached command-log
// evidence. It cannot prove the claimed command was actually executed.
func VerifySupplementEvidence(s Supplement, root string) []string {
	rep := Report{Findings: []Finding{}}
	for idx, v := range s.Verification {
		if v.OutputEvidence != nil {
			rep.Findings = append(rep.Findings, Finding{ID: fmt.Sprintf("supplement-verification-%d", idx), Evidence: []Evidence{*v.OutputEvidence}})
		}
	}
	return VerifyEvidence(rep, root)
}

// ReferencedEvidenceCount counts byte-backed evidence references, not the
// number of unique or truthful artifacts.
func ReferencedEvidenceCount(rep Report, s Supplement) int {
	n := 0
	for _, i := range rep.Items {
		n += len(i.Evidence)
	}
	for _, f := range rep.Findings {
		n += len(f.Evidence)
	}
	for _, v := range s.Verification {
		if v.OutputEvidence != nil {
			n++
		}
	}
	return n
}
