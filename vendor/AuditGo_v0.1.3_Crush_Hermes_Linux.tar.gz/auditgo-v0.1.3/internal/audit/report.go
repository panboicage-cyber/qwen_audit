package audit

import (
	"fmt"
	"os"
	"strings"
)

type ItemVerdict struct {
	ItemID        string     `json:"item_id"`
	Module        string     `json:"module"`
	PrimaryOwner  string     `json:"primary_owner"`
	Applicable    *bool      `json:"applicable"`
	Status        string     `json:"status"`
	InvariantHeld *bool      `json:"invariant_held"`
	EvidenceLevel string     `json:"evidence_level"`
	Evidence      []Evidence `json:"evidence"`
	Reason        string     `json:"reason"`
}
type Evidence struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
}
type Finding struct {
	ID             string     `json:"id"`
	Title          string     `json:"title"`
	ItemIDs        []string   `json:"item_ids"`
	Severity       string     `json:"severity"`
	EvidenceLevel  string     `json:"evidence_level"`
	Evidence       []Evidence `json:"evidence"`
	State          string     `json:"state"`
	CausalChain    string     `json:"causal_chain"`
	CounterReview  string     `json:"counter_review"`
	SmallestRepair string     `json:"smallest_repair"`
	RegressionTest string     `json:"regression_test"`
}
type Report struct {
	Schema                            string              `json:"schema"`
	TargetID                          string              `json:"target_id"`
	SourceRevision                    string              `json:"source_revision"`
	ConfigSHA256                      string              `json:"config_sha256"`
	RegistrySHA256                    string              `json:"registry_sha256"`
	ModuleStates                      map[string][]string `json:"module_states"`
	IndependentSpecialistsEstablished bool                `json:"independent_specialists_established"`
	Items                             []ItemVerdict       `json:"items"`
	Findings                          []Finding           `json:"findings"`
	RejectedFindings                  []Finding           `json:"rejected_findings"`
	Blockers                          []string            `json:"blockers"`
	SupportedOverclaim                bool                `json:"supported_overclaim"`
	AuditCompleteness                 string              `json:"audit_completeness"`
	RiskDisposition                   string              `json:"risk_disposition"`
	FinalDisposition                  string              `json:"final_disposition"`
}

func Seed(c Config, r Registry) Report {
	p := BuildPlan(c, r)
	rep := Report{Schema: ReturnSchema, TargetID: c.Target.ID, SourceRevision: c.Target.SourceRevision,
		ConfigSHA256: p.ConfigSHA256, RegistrySHA256: p.RegistrySHA256, ModuleStates: p.ModuleStates,
		Items: []ItemVerdict{}, Findings: []Finding{}, RejectedFindings: []Finding{},
		Blockers:          []string{"Unassessed seed: no evidence review has occurred"},
		AuditCompleteness: "EVIDENCE_INCOMPLETE", RiskDisposition: "PASS", FinalDisposition: "EVIDENCE_INCOMPLETE"}
	for _, i := range r.Items {
		state := "AUDITED"
		if i.Module != "CORE" {
			for k, group := range p.ModuleStates {
				if contains(group, i.Module) {
					state = k
					break
				}
			}
		}
		status := "BLOCKED"
		reason := "Not assessed: evidence must be collected and independently evaluated"
		if state != "AUDITED" {
			status = state
			reason = "Module state: " + state
		}
		rep.Items = append(rep.Items, ItemVerdict{ItemID: i.ID, Module: i.Module, PrimaryOwner: i.Module + " perspective",
			Status: status, EvidenceLevel: "NOT_ESTABLISHED", Evidence: []Evidence{}, Reason: reason})
	}
	return rep
}
func supported(x string) bool { return x == "CONFIRMED" || x == "STRONGLY_SUPPORTED" }
func validLevel(x string) bool {
	return contains([]string{"NOT_ESTABLISHED", "SPECULATIVE", "PLAUSIBLE", "STRONGLY_SUPPORTED", "CONFIRMED"}, x)
}
func validStatus(x string) bool {
	return contains([]string{"RUN", "ANALYZED", "BLOCKED", "NOT_APPLICABLE", "SKIPPED_BY_SELECTOR", "OUT_OF_SCOPE"}, x)
}
func validSeverity(x string) bool {
	return contains([]string{"LOW", "MEDIUM", "HIGH", "CRITICAL", "BLOCKER"}, x)
}
func Verdict(c Config, r Registry, rep Report) (completeness, risk, final string, problems []string) {
	problems = []string{}
	p := BuildPlan(c, r)
	if rep.Schema != ReturnSchema {
		problems = append(problems, "schema mismatch")
	}
	if rep.TargetID != p.TargetID || rep.SourceRevision != p.SourceRevision {
		problems = append(problems, "target identity/revision mismatch")
	}
	if rep.ConfigSHA256 != p.ConfigSHA256 || rep.RegistrySHA256 != p.RegistrySHA256 {
		problems = append(problems, "selector or registry digest mismatch")
	}
	for _, k := range []string{"AUDITED", "NOT_APPLICABLE", "SKIPPED_BY_SELECTOR", "OUT_OF_SCOPE"} {
		if len(rep.ModuleStates[k]) != len(p.ModuleStates[k]) {
			problems = append(problems, "module state mismatch: "+k)
			continue
		}
		for ix, x := range p.ModuleStates[k] {
			if rep.ModuleStates[k][ix] != x {
				problems = append(problems, "module state mismatch: "+k)
				break
			}
		}
	}
	if len(rep.ModuleStates) != 4 {
		problems = append(problems, "module_states requires exactly four groups")
	}
	known := map[string]Item{}
	for _, i := range r.Items {
		known[i.ID] = i
	}
	seen := map[string]bool{}
	incomplete := false
	for _, v := range rep.Items {
		i, ok := known[v.ItemID]
		if !ok {
			problems = append(problems, "unknown item id: "+v.ItemID)
			continue
		}
		if seen[v.ItemID] {
			problems = append(problems, "duplicate item id: "+v.ItemID)
		}
		seen[v.ItemID] = true
		if v.Module != i.Module {
			problems = append(problems, "wrong module for "+v.ItemID)
		}
		if !validStatus(v.Status) || !validLevel(v.EvidenceLevel) {
			problems = append(problems, "invalid status/evidence level for "+v.ItemID)
		}
		expected := "AUDITED"
		if i.Module != "CORE" {
			for state, names := range p.ModuleStates {
				if contains(names, i.Module) {
					expected = state
					break
				}
			}
		}
		if expected != "AUDITED" {
			if v.Status != expected {
				problems = append(problems, fmt.Sprintf("%s must have status %s", v.ItemID, expected))
			}
			if v.Applicable != nil || v.InvariantHeld != nil {
				problems = append(problems, "excluded/skipped item has asserted verdict: "+v.ItemID)
			}
		} else {
			if !contains([]string{"RUN", "ANALYZED", "BLOCKED", "NOT_APPLICABLE"}, v.Status) {
				problems = append(problems, "selected item has excluded status: "+v.ItemID)
			}
			if v.Status == "BLOCKED" {
				incomplete = true
			}
			if v.Status == "NOT_APPLICABLE" && (v.Applicable == nil || *v.Applicable || len(v.Evidence) == 0) {
				problems = append(problems, "N/A requires applicable=false and evidence: "+v.ItemID)
			}
			if v.Status == "RUN" && len(v.Evidence) == 0 {
				problems = append(problems, "RUN needs evidence: "+v.ItemID)
			}
			if v.Status != "NOT_APPLICABLE" && (v.Applicable == nil || v.InvariantHeld == nil || !supported(v.EvidenceLevel) || len(v.Evidence) == 0) {
				incomplete = true
			}
			if v.InvariantHeld != nil && !*v.InvariantHeld {
				linked := false
				for _, finding := range rep.Findings {
					if contains(finding.ItemIDs, v.ItemID) {
						linked = true
						break
					}
				}
				if !linked {
					incomplete = true
				}
			}
		}
		for _, e := range v.Evidence {
			if e.Path == "" || !validSHA(e.SHA256) {
				problems = append(problems, "invalid evidence digest: "+v.ItemID)
			}
		}
	}
	for _, i := range r.Items {
		if !seen[i.ID] {
			problems = append(problems, "missing item: "+i.ID)
		}
	}
	if len(rep.Blockers) > 0 {
		incomplete = true
	}
	if !provided(c.Target.SourceRevision) {
		incomplete = true
	}
	if c.Selectors.Controls["REQUIRE_INDEPENDENT_SPECIALISTS"] && !rep.IndependentSpecialistsEstablished {
		incomplete = true
	}
	risk = "PASS"
	high := false
	critical := false
	med := false
	findingIDs := map[string]bool{}
	for _, f := range rep.Findings {
		if f.ID == "" || findingIDs[f.ID] {
			problems = append(problems, "finding ID empty/duplicate: "+f.ID)
			continue
		}
		findingIDs[f.ID] = true
		if f.State != "SURVIVING" {
			problems = append(problems, "findings must have SURVIVING state: "+f.ID)
		}
		if !validLevel(f.EvidenceLevel) || !validSeverity(f.Severity) {
			problems = append(problems, "finding invalid evidence/severity: "+f.ID)
		}
		if len(f.ItemIDs) == 0 {
			problems = append(problems, "finding lacks item IDs: "+f.ID)
		}
		for _, id := range f.ItemIDs {
			if !seen[id] {
				problems = append(problems, "finding references unknown item: "+f.ID+"/"+id)
			}
		}
		if supported(f.EvidenceLevel) {
			if f.CausalChain == "" || f.CounterReview == "" || len(f.Evidence) == 0 {
				problems = append(problems, "supported finding lacks causal chain/counter-review/evidence: "+f.ID)
			}
			if f.Severity == "BLOCKER" {
				critical = true
			} else if f.Severity == "CRITICAL" || f.Severity == "HIGH" {
				high = true
			} else if f.Severity == "MEDIUM" || f.Severity == "LOW" {
				med = true
			}
		}
		for _, e := range f.Evidence {
			if e.Path == "" || !validSHA(e.SHA256) {
				problems = append(problems, "invalid finding evidence: "+f.ID)
			}
		}
	}
	for _, f := range rep.RejectedFindings {
		if f.ID == "" || findingIDs[f.ID] {
			problems = append(problems, "duplicate rejected finding: "+f.ID)
		}
		findingIDs[f.ID] = true
		if f.State != "REJECTED" || f.CounterReview == "" {
			problems = append(problems, "rejected finding needs REJECTED state and reason: "+f.ID)
		}
	}
	if rep.SupportedOverclaim {
		hasSupport := false
		for _, f := range rep.Findings {
			if supported(f.EvidenceLevel) {
				hasSupport = true
				break
			}
		}
		if !hasSupport {
			problems = append(problems, "supported_overclaim requires a surviving supported finding")
		}
	}
	if critical {
		risk = "CORE_INVARIANT_FAILURE"
	} else if high {
		risk = "HARDENING_REQUIRED"
	} else if rep.SupportedOverclaim {
		risk = "ARCHITECTURE_SOUND_CONTRACT_OVERCLAIMED"
	} else if med {
		risk = "PASS_WITH_HARDENING"
	}
	completeness = "COMPLETE"
	if incomplete {
		completeness = "EVIDENCE_INCOMPLETE"
	}
	final = risk
	if incomplete {
		final = "EVIDENCE_INCOMPLETE"
	}
	if rep.AuditCompleteness != completeness || rep.RiskDisposition != risk || rep.FinalDisposition != final {
		problems = append(problems, fmt.Sprintf("claimed disposition inconsistent: expected %s / %s / %s", completeness, risk, final))
	}
	return
}
func validSHA(s string) bool {
	if len(s) != 64 {
		return false
	}
	for _, c := range s {
		if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f') {
			return false
		}
	}
	return true
}
func ValidateReportBytes(raw []byte, c Config, r Registry) (Report, []string, error) {
	var rep Report
	if err := StrictDecode(raw, &rep); err != nil {
		return rep, nil, err
	}
	_, _, _, problems := Verdict(c, r, rep)
	return rep, problems, nil
}
func ReadAndValidateReport(path string, c Config, r Registry) (Report, []string, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return Report{}, nil, err
	}
	return ValidateReportBytes(b, c, r)
}
func Summary(rep Report) string {
	return strings.Join([]string{rep.FinalDisposition, rep.AuditCompleteness, rep.RiskDisposition}, " / ")
}
