package audit

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// VerifyEvidence verifies actual local bytes when explicitly supplied a root.
// No network URLs, symlink escapes or absolute evidence paths are followed.
// This is separate from report format validation, which checks SHA syntax only.
func VerifyEvidence(rep Report, root string) []string {
	problems := []string{}
	canonicalRoot, e := filepath.EvalSymlinks(root)
	if e != nil {
		return []string{fmt.Sprintf("evidence root inaccessible: %v", e)}
	}
	canonicalRoot, e = filepath.Abs(canonicalRoot)
	if e != nil {
		return []string{fmt.Sprintf("invalid evidence root: %v", e)}
	}
	check := func(label string, ev Evidence) {
		if filepath.IsAbs(ev.Path) || strings.Contains(ev.Path, "://") {
			problems = append(problems, label+": path must be relative and local")
			return
		}
		joined := filepath.Join(canonicalRoot, ev.Path)
		canonical, e := filepath.EvalSymlinks(joined)
		if e != nil {
			problems = append(problems, label+": evidence not readable: "+ev.Path)
			return
		}
		rel, e := filepath.Rel(canonicalRoot, canonical)
		if e != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
			problems = append(problems, label+": evidence escaped the root: "+ev.Path)
			return
		}
		data, e := os.ReadFile(canonical)
		if e != nil {
			problems = append(problems, label+": evidence read failed: "+ev.Path)
			return
		}
		if Digest(data) != ev.SHA256 {
			problems = append(problems, label+": SHA-256 does not match local bytes: "+ev.Path)
		}
	}
	for _, item := range rep.Items {
		for _, ev := range item.Evidence {
			check(item.ItemID, ev)
		}
	}
	for _, item := range rep.Findings {
		for _, ev := range item.Evidence {
			check(item.ID, ev)
		}
	}
	return problems
}
