package audit

import (
	"bytes"
	"crypto/sha256"
	"embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"sort"
	"strings"
)

const (
	SelectorSchema = "auditgo-selector.v1"
	RegistrySchema = "auditgo-registry.v1"
	PackSchema     = "auditgo-module-pack.v1"
	ReturnSchema   = "auditgo-return.v1"
)

var Types = []string{"DESIGN_CONTRACT", "IMPLEMENTATION", "RUNTIME_CONCURRENCY", "SECURITY_AUTHORITY", "DATA_INTEGRITY_HISTORY", "PROVENANCE_RELEASE", "RECOVERY_RESILIENCE", "AGENT_GOVERNANCE", "PREMATURE_CONFIDENCE"}
var Controls = []string{"ALLOW_FIXTURE_EXECUTION", "REQUIRE_INDEPENDENT_SPECIALISTS", "EXPORT_EVIDENCE_ZIP", "REPOSITORY_COMMIT_REQUESTED"}

//go:embed data/registry.json
var assets embed.FS

type Module struct {
	Name        string `json:"name"`
	Description string `json:"description"`
}
type Item struct {
	ID        string   `json:"id"`
	Module    string   `json:"module"`
	Objective string   `json:"objective"`
	Aliases   []string `json:"legacy_aliases"`
	Mandatory bool     `json:"mandatory"`
}
type Registry struct {
	Schema  string   `json:"schema"`
	Modules []Module `json:"modules"`
	Items   []Item   `json:"items"`
}
type Pack struct {
	Schema  string   `json:"schema"`
	Modules []Module `json:"modules"`
	Items   []Item   `json:"items"`
}
type Target struct {
	ID                    string   `json:"id"`
	Description           string   `json:"description"`
	Claims                []string `json:"claims"`
	Artifacts             []string `json:"artifacts"`
	SourceRevision        string   `json:"source_revision"`
	AuthorizedTestSurface string   `json:"authorized_test_surface"`
	DisposableEnvironment string   `json:"disposable_environment"`
	ProhibitedActions     []string `json:"prohibited_actions"`
}
type Selectors struct {
	AuditTypes map[string]bool `json:"audit_types"`
	Modules    map[string]bool `json:"modules"`
	Controls   map[string]bool `json:"controls"`
}
type Grounding struct {
	Surface        string   `json:"surface"` // UNKNOWN, PRESENT or ABSENT
	Scope          string   `json:"scope"`   // IN_SCOPE or OUT_OF_SCOPE
	BasisArtifacts []string `json:"basis_artifacts"`
	ScopeReason    string   `json:"scope_reason,omitempty"`
}
type Delivery struct {
	OutputDirectory string `json:"output_directory"`
	ReturnName      string `json:"return_name"`
	AuditBranch     string `json:"audit_branch"`
}
type Config struct {
	Schema          string               `json:"schema"`
	Target          Target               `json:"target"`
	Selectors       Selectors            `json:"selectors"`
	ModuleGrounding map[string]Grounding `json:"module_grounding"`
	Delivery        Delivery             `json:"delivery"`
}
type Plan struct {
	Schema         string              `json:"schema"`
	TargetID       string              `json:"target_id"`
	SourceRevision string              `json:"source_revision"`
	ConfigSHA256   string              `json:"config_sha256"`
	RegistrySHA256 string              `json:"registry_sha256"`
	EnabledTypes   []string            `json:"enabled_types"`
	ModuleStates   map[string][]string `json:"module_states"`
	SelectedItems  int                 `json:"selected_items"`
	MandatoryItems int                 `json:"mandatory_items"`
	SourceOnly     bool                `json:"source_only"`
	Limits         []string            `json:"limits"`
}

func StrictDecode(b []byte, v any) error {
	if err := rejectDuplicateKeys(b); err != nil {
		return err
	}
	dec := json.NewDecoder(bytes.NewReader(b))
	dec.DisallowUnknownFields()
	if err := dec.Decode(v); err != nil {
		return err
	}
	var extra any
	if err := dec.Decode(&extra); !errors.Is(err, io.EOF) {
		if err == nil {
			return errors.New("trailing JSON value")
		}
		return err
	}
	return nil
}
func Digest(b []byte) string { d := sha256.Sum256(b); return hex.EncodeToString(d[:]) }
func JSON(v any) []byte      { b, _ := json.MarshalIndent(v, "", "  "); return append(b, '\n') }

func DefaultRegistry() (Registry, error) {
	b, e := assets.ReadFile("data/registry.json")
	if e != nil {
		return Registry{}, e
	}
	var r Registry
	if e = StrictDecode(b, &r); e != nil {
		return r, e
	}
	return r, ValidateRegistry(r)
}
func LoadRegistry(packPaths []string) (Registry, error) {
	r, err := DefaultRegistry()
	if err != nil {
		return r, err
	}
	for _, p := range packPaths {
		raw, err := os.ReadFile(p)
		if err != nil {
			return r, err
		}
		var pack Pack
		if err = StrictDecode(raw, &pack); err != nil {
			return r, fmt.Errorf("pack %s: %w", p, err)
		}
		if pack.Schema != PackSchema {
			return r, fmt.Errorf("pack %s: invalid schema %q", p, pack.Schema)
		}
		r.Modules = append(r.Modules, pack.Modules...)
		r.Items = append(r.Items, pack.Items...)
	}
	return r, ValidateRegistry(r)
}
func ValidateRegistry(r Registry) error {
	if r.Schema != RegistrySchema {
		return fmt.Errorf("invalid registry schema %q", r.Schema)
	}
	names := map[string]bool{"CORE": true}
	ids := map[string]bool{}
	for _, m := range r.Modules {
		if !validKey(m.Name) || m.Name == "CORE" || names[m.Name] || strings.TrimSpace(m.Description) == "" {
			return fmt.Errorf("invalid or duplicate module %q", m.Name)
		}
		names[m.Name] = true
	}
	for _, i := range r.Items {
		if !names[i.Module] || i.ID == "" || ids[i.ID] || strings.TrimSpace(i.Objective) == "" {
			return fmt.Errorf("invalid or duplicate registry item %q (%q)", i.ID, i.Module)
		}
		ids[i.ID] = true
	}
	if !ids["CORE-001"] || !ids["CORE-024"] {
		return errors.New("mandatory core registry incomplete")
	}
	return nil
}
func validKey(s string) bool {
	if s == "" {
		return false
	}
	for _, c := range s {
		if !(c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '_') {
			return false
		}
	}
	return true
}
func DefaultConfig(r Registry) Config {
	c := Config{Schema: SelectorSchema,
		Target:          Target{ID: "REPLACE_TARGET", Description: "REPLACE_DESCRIPTION", Claims: []string{"REPLACE_VERBATIM_CLAIM"}, Artifacts: []string{}, SourceRevision: "NOT_PROVIDED", AuthorizedTestSurface: "NOT_PROVIDED", DisposableEnvironment: "NOT_PROVIDED", ProhibitedActions: []string{}},
		Selectors:       Selectors{AuditTypes: map[string]bool{}, Modules: map[string]bool{}, Controls: map[string]bool{}},
		ModuleGrounding: map[string]Grounding{},
		Delivery:        Delivery{OutputDirectory: "./audit-return", ReturnName: "audit_independent_return", AuditBranch: "NOT_PROVIDED"},
	}
	for _, t := range Types {
		c.Selectors.AuditTypes[t] = t == "DESIGN_CONTRACT"
	}
	for _, t := range Controls {
		c.Selectors.Controls[t] = t == "EXPORT_EVIDENCE_ZIP"
	}
	for _, m := range r.Modules {
		c.Selectors.Modules[m.Name] = false
		if m.Name != "CROSS_MODULE_COMPOUND" {
			c.ModuleGrounding[m.Name] = Grounding{Surface: "UNKNOWN", Scope: "IN_SCOPE", BasisArtifacts: []string{}}
		}
	}
	return c
}
func checkSwitches(path string, values map[string]bool, expected []string) error {
	if values == nil {
		return fmt.Errorf("%s: missing object", path)
	}
	if len(values) != len(expected) {
		return fmt.Errorf("%s: expected %d exact boolean keys, got %d", path, len(expected), len(values))
	}
	for _, key := range expected {
		if _, ok := values[key]; !ok {
			return fmt.Errorf("%s.%s: missing boolean", path, key)
		}
	}
	return nil
}

// ValidateConfig checks every known key and type. JSON native bools are mandatory;
// malformed/null/string selectors fail during decoding or key validation.
func ValidateConfig(c Config, r Registry) error {
	if c.Schema != SelectorSchema {
		return fmt.Errorf("selector schema: expected %s", SelectorSchema)
	}
	if strings.TrimSpace(c.Target.ID) == "" || strings.HasPrefix(c.Target.ID, "REPLACE_") {
		return errors.New("target.id must be a real target identifier")
	}
	if len(c.Target.Claims) == 0 {
		return errors.New("target.claims: provide at least one verbatim claim")
	}
	for _, claim := range c.Target.Claims {
		if strings.TrimSpace(claim) == "" || strings.HasPrefix(claim, "REPLACE_") {
			return errors.New("target.claims must contain real claims")
		}
	}
	if err := checkSwitches("selectors.audit_types", c.Selectors.AuditTypes, Types); err != nil {
		return err
	}
	count := 0
	for _, v := range c.Selectors.AuditTypes {
		if v {
			count++
		}
	}
	if count == 0 {
		return errors.New("selectors.audit_types: at least one true required")
	}
	if err := checkSwitches("selectors.controls", c.Selectors.Controls, Controls); err != nil {
		return err
	}
	modNames := make([]string, 0, len(r.Modules))
	for _, m := range r.Modules {
		modNames = append(modNames, m.Name)
	}
	if err := checkSwitches("selectors.modules", c.Selectors.Modules, modNames); err != nil {
		return err
	}
	if len(c.ModuleGrounding) != len(r.Modules)-1 {
		return errors.New("module_grounding: must include each non-compound module exactly once")
	}
	for _, m := range r.Modules {
		if m.Name == "CROSS_MODULE_COMPOUND" {
			continue
		}
		g, ok := c.ModuleGrounding[m.Name]
		if !ok {
			return fmt.Errorf("module_grounding.%s: missing", m.Name)
		}
		if g.Surface != "UNKNOWN" && g.Surface != "PRESENT" && g.Surface != "ABSENT" {
			return fmt.Errorf("module_grounding.%s.surface: invalid %q", m.Name, g.Surface)
		}
		if g.Scope != "IN_SCOPE" && g.Scope != "OUT_OF_SCOPE" {
			return fmt.Errorf("module_grounding.%s.scope: invalid %q", m.Name, g.Scope)
		}
		if g.Scope == "OUT_OF_SCOPE" && strings.TrimSpace(g.ScopeReason) == "" {
			return fmt.Errorf("module_grounding.%s.scope_reason required", m.Name)
		}
		if g.Surface == "ABSENT" && len(g.BasisArtifacts) == 0 {
			return fmt.Errorf("module_grounding.%s: ABSENT requires evidence artifact(s)", m.Name)
		}
	}
	if strings.TrimSpace(c.Delivery.ReturnName) == "" {
		return errors.New("delivery.return_name required")
	}
	return nil
}
func ParseConfig(raw []byte, r Registry) (Config, error) {
	var c Config
	if err := validateLiteralBooleans(raw); err != nil {
		return c, fmt.Errorf("SELECTOR_VALIDATION_FAILED: %w", err)
	}
	if err := StrictDecode(raw, &c); err != nil {
		return c, fmt.Errorf("SELECTOR_VALIDATION_FAILED: %w", err)
	}
	if err := ValidateConfig(c, r); err != nil {
		return c, fmt.Errorf("SELECTOR_VALIDATION_FAILED: %w", err)
	}
	return c, nil
}
func BuildPlan(c Config, r Registry) Plan {
	p := Plan{Schema: "auditgo-plan.v1", TargetID: c.Target.ID, SourceRevision: c.Target.SourceRevision,
		ConfigSHA256: Digest(JSON(c)), RegistrySHA256: Digest(JSON(r)), ModuleStates: map[string][]string{}, Limits: []string{}}
	for _, state := range []string{"AUDITED", "NOT_APPLICABLE", "SKIPPED_BY_SELECTOR", "OUT_OF_SCOPE"} {
		p.ModuleStates[state] = []string{}
	}
	for _, t := range Types {
		if c.Selectors.AuditTypes[t] {
			p.EnabledTypes = append(p.EnabledTypes, t)
		}
	}
	auditedDomains := 0
	for _, m := range r.Modules {
		if m.Name == "CROSS_MODULE_COMPOUND" {
			continue
		}
		state := "AUDITED"
		g := c.ModuleGrounding[m.Name]
		if !c.Selectors.Modules[m.Name] {
			state = "SKIPPED_BY_SELECTOR"
		} else if g.Scope == "OUT_OF_SCOPE" {
			state = "OUT_OF_SCOPE"
		} else if g.Surface == "ABSENT" {
			state = "NOT_APPLICABLE"
		}
		if state == "AUDITED" {
			auditedDomains++
		}
		p.ModuleStates[state] = append(p.ModuleStates[state], m.Name)
	}
	compound := "SKIPPED_BY_SELECTOR"
	if c.Selectors.Modules["CROSS_MODULE_COMPOUND"] {
		if auditedDomains < 2 {
			compound = "NOT_APPLICABLE"
		} else {
			compound = "AUDITED"
		}
	}
	p.ModuleStates[compound] = append(p.ModuleStates[compound], "CROSS_MODULE_COMPOUND")
	for _, i := range r.Items {
		if i.Module == "CORE" || contains(p.ModuleStates["AUDITED"], i.Module) {
			p.SelectedItems++
			if i.Mandatory {
				p.MandatoryItems++
			}
		}
	}
	p.SourceOnly = !c.Selectors.Controls["ALLOW_FIXTURE_EXECUTION"] || !provided(c.Target.AuthorizedTestSurface) || !provided(c.Target.DisposableEnvironment)
	if p.SourceOnly {
		p.Limits = append(p.Limits, "Source-only: fixture execution not enabled and separately bounded by authorized surface plus disposable environment")
	}
	if c.Selectors.Controls["REPOSITORY_COMMIT_REQUESTED"] {
		p.Limits = append(p.Limits, "Commit selector is a request, not repository write authority; separate explicit permission required")
	}
	if c.Selectors.Controls["REQUIRE_INDEPENDENT_SPECIALISTS"] {
		p.Limits = append(p.Limits, "Independent reviewers require distinct actual agent contexts with separately preserved first passes")
	}
	if !provided(c.Target.SourceRevision) {
		p.Limits = append(p.Limits, "Exact source revision not provided; provenance gate incomplete")
	}
	return p
}
func contains(xs []string, x string) bool {
	for _, y := range xs {
		if x == y {
			return true
		}
	}
	return false
}
func provided(x string) bool {
	s := strings.TrimSpace(x)
	return s != "" && s != "UNKNOWN" && s != "NOT_PROVIDED" && !strings.HasPrefix(s, "REPLACE_")
}
func SortedItemIDs(r Registry) []string {
	ids := make([]string, 0, len(r.Items))
	for _, i := range r.Items {
		ids = append(ids, i.ID)
	}
	sort.Strings(ids)
	return ids
}

// Token-walking preflight rejects duplicate object keys (including nested keys).
// encoding/json by itself silently retains the last duplicate.
func rejectDuplicateKeys(b []byte) error {
	d := json.NewDecoder(bytes.NewReader(b))
	var walk func() error
	walk = func() error {
		tok, err := d.Token()
		if err != nil {
			return err
		}
		open, ok := tok.(json.Delim)
		if !ok {
			return nil
		}
		switch open {
		case '{':
			seen := map[string]bool{}
			for d.More() {
				keyTok, err := d.Token()
				if err != nil {
					return err
				}
				key, ok := keyTok.(string)
				if !ok {
					return errors.New("invalid JSON object key")
				}
				if seen[key] {
					return fmt.Errorf("duplicate JSON key %q", key)
				}
				seen[key] = true
				if err := walk(); err != nil {
					return err
				}
			}
			_, err := d.Token()
			return err
		case '[':
			for d.More() {
				if err := walk(); err != nil {
					return err
				}
			}
			_, err := d.Token()
			return err
		default:
			return errors.New("unexpected JSON delimiter")
		}
	}
	if err := walk(); err != nil {
		return err
	}
	if _, err := d.Token(); !errors.Is(err, io.EOF) {
		if err == nil {
			return errors.New("trailing JSON value")
		}
		return err
	}
	return nil
}
func validateLiteralBooleans(raw []byte) error {
	var root struct {
		Selectors map[string]json.RawMessage `json:"selectors"`
	}
	if err := json.Unmarshal(raw, &root); err != nil {
		return err
	}
	if root.Selectors == nil {
		return errors.New("selectors: required")
	}
	for _, section := range []string{"audit_types", "modules", "controls"} {
		subRaw, ok := root.Selectors[section]
		if !ok {
			return fmt.Errorf("selectors.%s: required", section)
		}
		var switches map[string]json.RawMessage
		if err := json.Unmarshal(subRaw, &switches); err != nil {
			return fmt.Errorf("selectors.%s must be an object: %w", section, err)
		}
		if switches == nil {
			return fmt.Errorf("selectors.%s must not be null", section)
		}
		for k, v := range switches {
			if string(v) != "true" && string(v) != "false" {
				return fmt.Errorf("selectors.%s.%s: expected native true/false, got %s", section, k, string(v))
			}
		}
	}
	return nil
}
