package audit

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func fixture(t *testing.T) (Config, Registry) {
	t.Helper()
	r, e := DefaultRegistry()
	if e != nil {
		t.Fatal(e)
	}
	c := DefaultConfig(r)
	c.Target.ID = "sample-repo-pr-4"
	c.Target.Claims = []string{"Exactly once under retry"}
	c.Target.SourceRevision = "abc123"
	return c, r
}
func TestRegistryAndPlan(t *testing.T) {
	c, r := fixture(t)
	if len(r.Items) != 383 {
		t.Fatalf("items=%d", len(r.Items))
	}
	c.Selectors.Modules["GO_NATIVE_BINARY"] = true
	c.Selectors.Modules["CROSS_MODULE_COMPOUND"] = true
	p := BuildPlan(c, r)
	if p.SelectedItems != 155 {
		t.Fatalf("selected items %d", p.SelectedItems)
	}
	if !contains(p.ModuleStates["AUDITED"], "GO_NATIVE_BINARY") || !contains(p.ModuleStates["NOT_APPLICABLE"], "CROSS_MODULE_COMPOUND") {
		t.Fatalf("wrong states: %#v", p.ModuleStates)
	}
	if !p.SourceOnly {
		t.Fatal("implicit fixture permission")
	}
	c.Selectors.Modules["CANONICAL_HASH"] = true
	p = BuildPlan(c, r)
	if !contains(p.ModuleStates["AUDITED"], "CROSS_MODULE_COMPOUND") {
		t.Fatalf("missing compound: %#v", p.ModuleStates)
	}
}
func TestConfigRejectsLiteralViolations(t *testing.T) {
	c, r := fixture(t)
	raw := JSON(c)
	cases := map[string][]byte{
		"string true": bytes.Replace(raw, []byte(`"GO_NATIVE_BINARY": false`), []byte(`"GO_NATIVE_BINARY": "true"`), 1),
		"null":        bytes.Replace(raw, []byte(`"GO_NATIVE_BINARY": false`), []byte(`"GO_NATIVE_BINARY": null`), 1),
		"number":      bytes.Replace(raw, []byte(`"GO_NATIVE_BINARY": false`), []byte(`"GO_NATIVE_BINARY": 1`), 1),
		"missing":     bytes.Replace(raw, []byte(`"GO_NATIVE_BINARY": false,`), []byte(``), 1),
		"duplicate":   bytes.Replace(raw, []byte(`"GO_NATIVE_BINARY": false`), []byte(`"GO_NATIVE_BINARY": false, "GO_NATIVE_BINARY": true`), 1),
	}
	for name, b := range cases {
		t.Run(name, func(t *testing.T) {
			if bytes.Equal(b, raw) {
				t.Fatal("test transform failed")
			}
			if _, e := ParseConfig(b, r); e == nil {
				t.Fatal("accepted invalid boolean")
			}
		})
	}
}
func TestScopeStates(t *testing.T) {
	c, r := fixture(t)
	c.Selectors.Modules["CANONICAL_HASH"] = true
	g := c.ModuleGrounding["CANONICAL_HASH"]
	g.Surface = "ABSENT"
	g.BasisArtifacts = []string{"file-list-hash"}
	c.ModuleGrounding["CANONICAL_HASH"] = g
	if e := ValidateConfig(c, r); e != nil {
		t.Fatal(e)
	}
	if !contains(BuildPlan(c, r).ModuleStates["NOT_APPLICABLE"], "CANONICAL_HASH") {
		t.Fatal("absence not respected")
	}
	g.BasisArtifacts = nil
	c.ModuleGrounding["CANONICAL_HASH"] = g
	if e := ValidateConfig(c, r); e == nil {
		t.Fatal("unproven N/A")
	}
	g.Surface = "UNKNOWN"
	g.Scope = "OUT_OF_SCOPE"
	g.ScopeReason = "Owner excludes cryptographic surface"
	c.ModuleGrounding["CANONICAL_HASH"] = g
	if e := ValidateConfig(c, r); e != nil {
		t.Fatal(e)
	}
	if !contains(BuildPlan(c, r).ModuleStates["OUT_OF_SCOPE"], "CANONICAL_HASH") {
		t.Fatal("scope exclusion not respected")
	}
}
func TestSeedHonestAndFalseGreenRejected(t *testing.T) {
	c, r := fixture(t)
	rep := Seed(c, r)
	_, _, _, issues := Verdict(c, r, rep)
	if len(issues) != 0 {
		t.Fatalf("honest seed invalid: %v", issues)
	}
	if rep.AuditCompleteness != "EVIDENCE_INCOMPLETE" {
		t.Fatal("seed asserted complete")
	}
	rep.FinalDisposition = "PASS"
	rep.AuditCompleteness = "COMPLETE"
	_, _, _, issues = Verdict(c, r, rep)
	if len(issues) == 0 {
		t.Fatal("false green accepted")
	}
	rep.FinalDisposition = "EVIDENCE_INCOMPLETE"
	rep.AuditCompleteness = "EVIDENCE_INCOMPLETE"
	rep.Items = rep.Items[1:]
	_, _, _, issues = Verdict(c, r, rep)
	if len(issues) == 0 {
		t.Fatal("incomplete coverage accepted")
	}
}
func TestSupportedHighSeverityRisk(t *testing.T) {
	c, r := fixture(t)
	rep := Seed(c, r)
	rep.Findings = []Finding{{ID: "F-001", Title: "High evidence backed", ItemIDs: []string{"CORE-001"}, Severity: "HIGH", EvidenceLevel: "CONFIRMED", State: "SURVIVING", CausalChain: "P->M->E->O->B->INV", CounterReview: "Independently checked", Evidence: []Evidence{{Path: "evidence.txt", SHA256: strings.Repeat("a", 64)}}}}
	rep.RiskDisposition = "HARDENING_REQUIRED"
	_, risk, fin, issues := Verdict(c, r, rep)
	if risk != "HARDENING_REQUIRED" || fin != "EVIDENCE_INCOMPLETE" || len(issues) > 0 {
		t.Fatalf("risk=%s fin=%s issues=%v", risk, fin, issues)
	}
}
func TestPackCannotReplaceCore(t *testing.T) {
	c, r := fixture(t)
	_ = c
	dir := t.TempDir()
	p := filepath.Join(dir, "module.json")
	pack := Pack{Schema: PackSchema, Modules: []Module{{Name: "SPECIAL_GO", Description: "Extra Go checks"}}, Items: []Item{{ID: "CUSTOM-001", Module: "SPECIAL_GO", Objective: "Check extra rule"}}}
	if e := os.WriteFile(p, JSON(pack), 0600); e != nil {
		t.Fatal(e)
	}
	extended, e := LoadRegistry([]string{p})
	if e != nil {
		t.Fatal(e)
	}
	if len(extended.Items) != len(r.Items)+1 {
		t.Fatal("module pack item missing")
	}
	custom := DefaultConfig(extended)
	custom.Target.ID = "sample"
	custom.Target.Claims = []string{"proven claim"}
	custom.Selectors.Modules["SPECIAL_GO"] = true
	if e := ValidateConfig(custom, extended); e != nil {
		t.Fatal(e)
	}
	pack.Items[0].ID = "CORE-001"
	_ = os.WriteFile(p, JSON(pack), 0600)
	if _, e := LoadRegistry([]string{p}); e == nil {
		t.Fatal("accepted core shadowing")
	}
}
func TestEvidenceRoots(t *testing.T) {
	dir := t.TempDir()
	data := []byte("trusted bytes")
	if e := os.WriteFile(filepath.Join(dir, "proof.txt"), data, 0600); e != nil {
		t.Fatal(e)
	}
	rep := Report{Items: []ItemVerdict{{ItemID: "CORE-001", Evidence: []Evidence{{Path: "proof.txt", SHA256: Digest(data)}}}}}
	if issues := VerifyEvidence(rep, dir); len(issues) > 0 {
		t.Fatal(issues)
	}
	rep.Items[0].Evidence[0].SHA256 = strings.Repeat("0", 64)
	if issues := VerifyEvidence(rep, dir); len(issues) == 0 {
		t.Fatal("accepted false evidence digest")
	}
	rep.Items[0].Evidence[0].Path = "../secrets.txt"
	if issues := VerifyEvidence(rep, dir); len(issues) == 0 {
		t.Fatal("accepted escape")
	}
}
func TestJSONStable(t *testing.T) {
	c, r := fixture(t)
	a := JSON(BuildPlan(c, r))
	b := JSON(BuildPlan(c, r))
	if !bytes.Equal(a, b) {
		t.Fatal("nondeterministic plan")
	}
	if !json.Valid(a) {
		t.Fatal("invalid JSON")
	}
}
func TestRenderedMission(t *testing.T) {
	c, r := fixture(t)
	c.Selectors.Modules["GO_NATIVE_BINARY"] = true
	prompt := Render(c, r)
	for _, required := range []string{"CORE-024", "GNB-131", "SELECTOR_VALIDATION_FAILED", "# Final Disposition", "No merge, push, release"} {
		if !strings.Contains(prompt, required) {
			t.Fatalf("missing %s", required)
		}
	}
	if strings.Contains(prompt, "TSP-001") {
		t.Fatal("implicitly included unselected module")
	}
}
