package audit

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestReceiptKeepsRiskCompletenessSeparate(t *testing.T) {
	c, r := fixture(t)
	c.Selectors.Modules["GO_NATIVE_BINARY"] = true
	rep := Seed(c, r)
	raw := JSON(rep)
	receipt, err := BuildReceipt(c, r, rep, JSON(c), raw, nil, "NOT_CHECKED")
	if err != nil {
		t.Fatal(err)
	}
	if receipt.Status != "EVIDENCE_INCOMPLETE" || receipt.Outcome.RiskDisposition != "PASS" || receipt.Outcome.FinalDisposition != "EVIDENCE_INCOMPLETE" {
		t.Fatalf("false promotion: %#v", receipt.Outcome)
	}
	if receipt.Coverage.Selected != 155 || receipt.Coverage.Blocked != 155 || receipt.Coverage.Assessed != 0 {
		t.Fatalf("wrong coverage: %#v", receipt.Coverage)
	}
	if receipt.Provenance.ReturnInputSHA256 != Digest(raw) || receipt.Provenance.ConfigInputSHA256 != Digest(JSON(c)) {
		t.Fatal("input bytes hashes incorrect")
	}
	text := RenderReceipt(receipt)
	if !strings.Contains(text, "not final acceptance") || strings.Contains(text, "tests passed") {
		t.Fatalf("misleading summary: %s", text)
	}
	rep.FinalDisposition = "PASS"
	if _, err := BuildReceipt(c, r, rep, JSON(c), JSON(rep), nil, "NOT_CHECKED"); err == nil {
		t.Fatal("false green report accepted")
	}
}
func TestReceiptSupplementParsedAndAttributed(t *testing.T) {
	c, r := fixture(t)
	rep := Seed(c, r)
	s := Supplement{SchemaVersion: SupplementSchema, Scope: "Source-only Go audit"}
	s.ChangedFiles = []FileChange{{Path: "main.go", BeforeSHA256: strings.Repeat("a", 64), AfterSHA256: strings.Repeat("b", 64)}}
	exit := 0
	s.Verification = []CommandEvidence{{Command: "go test ./...", CWD: "/repo", ExitCode: &exit, Result: "10 reported passed"}}
	s.Boundaries = []string{"No release authorized"}
	s.Limitations = []string{"External tests not independently replayed"}
	s.Next = []string{"Review findings"}
	raw := JSON(s)
	rcpt, err := BuildReceipt(c, r, rep, JSON(c), JSON(rep), raw, "NOT_CHECKED")
	if err != nil {
		t.Fatal(err)
	}
	if len(rcpt.ChangedFiles) != 1 || len(rcpt.Verification) != 1 || rcpt.Provenance.SupplementInputSHA256 != Digest(raw) {
		t.Fatalf("supplement lost: %#v", rcpt)
	}
	if !strings.Contains(rcpt.Attestation, "not independently replayed") || !strings.Contains(RenderReceipt(rcpt), "externally reported") {
		t.Fatal("missing evidence attribution")
	}
}
func TestReceiptStrictSupplementRejectsFalseProvenance(t *testing.T) {
	cases := []string{
		`{ "schema_version":"auditgo-closeout-supplement/v1","verification":[{"command":"echo x","result":"passed","exit_code":"0"}] }`,
		`{ "schema_version":"auditgo-closeout-supplement/v1","changed_files":[{"path":"x","before_sha256":"abc","after_sha256":"def"}] }`,
		`{ "schema_version":"auditgo-closeout-supplement/v1","reviewed":true }`,
		`{ "schema_version":"auditgo-closeout-supplement/v1","scope":"a","scope":"b" }`,
	}
	for _, raw := range cases {
		if _, err := ParseSupplement([]byte(raw)); err == nil {
			t.Fatalf("accepted %s", raw)
		}
	}
}
func TestVerificationLogBytesCheck(t *testing.T) {
	root := t.TempDir()
	data := []byte("authentic output")
	if err := os.WriteFile(filepath.Join(root, "log.txt"), data, 0600); err != nil {
		t.Fatal(err)
	}
	s := Supplement{Verification: []CommandEvidence{{Command: "go test", Result: "passed", OutputEvidence: &Evidence{Path: "log.txt", SHA256: Digest(data)}}}}
	if problems := VerifySupplementEvidence(s, root); len(problems) > 0 {
		t.Fatalf("correct digest rejected: %v", problems)
	}
	s.Verification[0].OutputEvidence.Path = "../log.txt"
	if problems := VerifySupplementEvidence(s, root); len(problems) == 0 {
		t.Fatal("outside path accepted")
	}
}
func TestReceiptJSONDeterministic(t *testing.T) {
	c, r := fixture(t)
	rep := Seed(c, r)
	a, err := BuildReceipt(c, r, rep, JSON(c), JSON(rep), nil, "NO_REFERENCED_EVIDENCE")
	if err != nil {
		t.Fatal(err)
	}
	b, err := BuildReceipt(c, r, rep, JSON(c), JSON(rep), nil, "NO_REFERENCED_EVIDENCE")
	if err != nil {
		t.Fatal(err)
	}
	if string(JSON(a)) != string(JSON(b)) {
		t.Fatal("nondeterministic receipt")
	}
	if !json.Valid(JSON(a)) {
		t.Fatal("invalid JSON")
	}
	if !strings.Contains(strings.Join(a.Limitations, " "), "no referenced evidence") {
		t.Fatalf("no evidence limitation missing: %+v", a.Limitations)
	}
}
