# AuditGo — Portable Audit Prompt Agent Toolkit (v0.1.3)

**A single pure-Go, vendor-neutral CLI and read-only local MCP server that turns a reusable adversarial audit battery into deterministic, scope-bound audit missions.**

AuditGo is inspired by [Engram's installation and portability model](https://github.com/Gentleman-Programming/engram/blob/main/docs/INSTALLATION.md): build once into a native binary, avoid requiring Node/Python at runtime, offer CLI and agent-harness integration, keep configuration explicit, and provide a `doctor` command. **It does not require, embed, or implement Engram or its memory database.**

## What is implemented

- **383 imported canonical audit items**: 24 always-on CORE + 359 domain items across 11 domain inventories. A twelfth switch, `CROSS_MODULE_COMPOUND`, controls cross-domain synthesis and adds no stand-alone checklist IDs.
- **9 audit-type switches**, **12 module switches**, **4 operation switches**. Every selector is a JSON **native `true` or `false`**, with no defaults, coercion, null or omitted keys in a submitted configuration.
- **One deterministic plan** resolving `AUDITED`, `NOT_APPLICABLE`, `SKIPPED_BY_SELECTOR`, `OUT_OF_SCOPE`, and all source-only restrictions.
- **Dynamic extension packs**: add module/checklist inventories with data-only JSON; never override CORE or another item ID.
- **Prompt renderer**: outputs the selected audit mission, core invariants, coverage obligations, stage-by-stage script, safety limits, 17 report headings, and fixed outcome model.
- **Unassessed checkpoint generator**: returns one item record per canonical item, with BLOCKED rather than invented results.
- **Return validator**: checks exact revision/config/registry identity, module state arrays, checklist completeness, evidence digest syntax, findings and disposition consistency.
- **Operational closeout receipts**: renders a short user-facing result plus deterministic JSON evidence receipt, optional reported execution history and hash sidecar, without claiming extra authority or proof. See [`docs/CLOSEOUT-RECEIPT.md`](docs/CLOSEOUT-RECEIPT.md). `-evidence-root` additionally verifies actual local evidence file bytes (no path escapes).
- **Local MCP stdio**: exposes `audit_modules`, `audit_config`, `audit_plan`, `audit_render`, `audit_seed`, `audit_validate`, `audit_closeout` to compatible agent clients. No network listener, daemon, API key, CGO or third-party Go library.
- **Opt-in external agent execution**: `invoke -- executable args...` passes the rendered prompt on stdin to a command *you explicitly select*. The invoked agent's permissions are outside AuditGo's enforcement boundary.

## Fast start

Requires **Go 1.23+ for builds**; the prebuilt binary needs **no Go installation**.

```bash
# From the downloaded source package:
go build -o auditgo ./cmd/auditgo
./auditgo doctor

# Produce strict selectors for a specific revision. No test execution enabled.
./auditgo init -out audit.json \
  -target "project/PR-4" -description "Go PR regression audit" \
  -revision "FULL_COMMIT_SHA_FROM_GITHUB" \
  -claim "The decoder rejects all malformed scalar values" \
  -type IMPLEMENTATION -type SECURITY_AUTHORITY \
  -module GO_NATIVE_BINARY -module CANONICAL_HASH

./auditgo modules
./auditgo plan -config audit.json
./auditgo render -config audit.json -out mission.md
./auditgo seed -config audit.json -out return.json

# After an external agent has filled in the return with actual evidence:
./auditgo validate -config audit.json -report return.json \
  -evidence-root ./audit-evidence

# Convert a validated return into a short operational update + machine receipt:
./auditgo closeout -config audit.json -report return.json -out-dir ./closeout-001
```

Change the example revision string to an **actual pinned SHA** before evaluating results. You can use a different set of `-type` and `-module` switches for spec, Python, TS, Rust, SQL, Merkle, wiki, agent governance, release provenance or recovery audits—without editing the source prompt.

`init` defaults to DESIGN_CONTRACT=true only when `-type` is omitted, and **all modules remain false** unless explicitly selected. The 24 CORE checks always remain active. Output files are created with restrictive permissions and are not silently overwritten.

## Install on Linux, macOS or Windows

Build on the target operating system:

```bash
go build -trimpath -o auditgo ./cmd/auditgo
# Windows: go build -trimpath -o auditgo.exe ./cmd/auditgo
```

Or cross-compile on a Go-equipped builder:

```bash
CGO_ENABLED=0 GOOS=linux   GOARCH=amd64 go build -trimpath -o auditgo-linux-amd64 ./cmd/auditgo
CGO_ENABLED=0 GOOS=darwin  GOARCH=arm64 go build -trimpath -o auditgo-darwin-arm64 ./cmd/auditgo
CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go build -trimpath -o auditgo-windows-amd64.exe ./cmd/auditgo
```

Build packages are provided separately for Linux/macOS/Windows, amd64/arm64. There is no `go install github.com/...@latest` path **until you publish this module to a real repository**, at which point update `go.mod` and local imports to your chosen canonical module path.

## Use from agents via MCP

Print the intended client's configuration snippet without changing local configuration:

```bash
./auditgo setup -client crush
./auditgo setup -client hermes
./auditgo setup -client opencode
./auditgo setup -client generic
```

### Crush (Go terminal agent)

Current Crush reads a Bash-based [`crushrc`](https://github.com/charmbracelet/crush/blob/main/docs/config/README.md), usually `~/.config/crush/crushrc`. Your checkout may contain `crush.json`, but that is the legacy format. `auditgo setup -client crush` prints one properly shell-quoted `mcp add auditgo --type stdio --command '...' --args mcp` entry. **Merge that line into an existing trusted `crushrc`; do not overwrite the file**. Project `.crushrc` has higher priority than global settings and executes with the user's shell privileges, so review it before enabling. Restart Crush to load the new server.

### Hermes Agent (Python agent harness, Go MCP server)

Current Hermes reads MCP entries from `~/.hermes/config.yaml` using a YAML mapping called `mcp_servers`. Run `auditgo setup -client hermes`, then merge the **`auditgo` child entry** under the *existing* `mcp_servers:` key. Do not create a duplicate YAML root mapping or overwrite agent settings. The snippet includes an explicit allowlist of AuditGo's seven local read-only tools and disables resource/prompt utilities. Reload Hermes with `/reload-mcp` or restart it. To check the connection, run `hermes mcp test auditgo` from a shell; this verifies that Hermes can connect and enumerate tools, **not** that an audit has been performed. Official docs: [Hermes MCP](https://github.com/NousResearch/hermes-agent/blob/main/website/docs/user-guide/features/mcp.md).

### OpenCode or generic MCP clients

The existing OpenCode adapter uses `mcp` / `type: local` / a command array. The generic example uses `mcpServers` / `command` / `args`. Do not treat the generic JSON snippet as Hermes or modern Crush configuration. Integrations remain **operator-reviewed snippets**, not automatic installers.

The MCP transport is stdio: it does not open a network listener, store agent credentials, or independently inspect the codebase. It supplies check inventories, audit plans, prompts, unassessed ledgers and structural return validation; a separately authorized client still gathers evidence. 

**Agent-first setup:** `audit_config` accepts typed fields (`target_id`, `claim`, `audit_types`, optional `modules`, `description`, `source_revision`), with enum validation for audit-type and module values. It returns a **complete, strict** `auditgo-selector.v1` JSON object, with all unselected switches explicitly `false`. Pass that entire JSON object, encoded as a **string**, in `config_json` for `audit_plan`, `audit_render`, or `audit_seed`—do not reconstruct the switches manually. `audit_modules` also lists all nine audit types, controls, and module inventories. An agent can call `audit_config` first to avoid trial-and-error errors such as missing `RUNTIME_CONCURRENCY`.

MCP tools `audit_plan`, `audit_render`, `audit_seed` and `audit_validate` accept `config_json` as a string containing the **entire strict JSON selector**; `audit_validate` additionally accepts a `report_json` string. `audit_config` creates configuration data only: it does not inspect source code or run any tests. After validating an evidence-filled audit return, `audit_closeout` produces a conversational `summary_markdown` and `auditgo-evidence-receipt/v1` object. It can take an optional reported-activity supplement but does not replay tests or verify local evidence bytes via MCP. External module packs can be loaded with `auditgo mcp -pack /path/to/pack.json` when launching the server. All exposed MCP operations are local, read-only and stateless.

For agents that accept prompts via stdin, explicitly opt into external execution:

```bash
./auditgo invoke -config audit.json -- /path/to/your-agent --some-flag
```

**Warning:** `invoke` starts the chosen external executable with the current user environment and inherited permissions. That program might have network, filesystem or shell capabilities. AuditGo itself does not sandbox or grant/deny the external agent's behavior; use a separate least-privilege/disposable environment if executing tests. Alternatively, use `render` and manually paste the mission into any agent.

## Audit outcome contract

Every selected item is assessed or explicitly blocked. A false switch stays skipped, selected unknown surfaces remain in the ledger, `OUT_OF_SCOPE` requires an explicit scope reason, and N/A requires a cited basis. Supporting evidence is not the same as verified actual bytes unless separately checked.

Two independent axes are retained:

| Axis | Values |
| --- | --- |
| `audit_completeness` | `COMPLETE`, `EVIDENCE_INCOMPLETE` |
| `risk_disposition` | `PASS`, `PASS_WITH_HARDENING`, `ARCHITECTURE_SOUND_CONTRACT_OVERCLAIMED`, `HARDENING_REQUIRED`, `CORE_INVARIANT_FAILURE` |
| `final_disposition` | Equals risk only when complete; otherwise `EVIDENCE_INCOMPLETE` |

`SELECTOR_VALIDATION_FAILED` is a pre-audit halt, not a passing report. Findings influence risk only if at least `STRONGLY_SUPPORTED`; incomplete evidence affects completeness. A validator-success message means *structural consistency*, not that the assistant actually executed tests or that findings are scientifically true. The initial seed is intentionally incomplete and must never be presented as a completed audit. A valid-but-incomplete return may be closed out with `final_disposition=EVIDENCE_INCOMPLETE` while retaining provisional technical risk. `closeout` does not perform audits or independently verify test execution.

## Extend the audit inventory without recompiling

See [`examples/custom-module-pack.json`](examples/custom-module-pack.json). Then:

```bash
./auditgo init -pack examples/custom-module-pack.json \
  -target "example-custom" -claim "Config is never reloaded without validation" \
  -module CUSTOM_CONFIG -out custom-config.json
./auditgo plan -pack examples/custom-module-pack.json -config custom-config.json
./auditgo render -pack examples/custom-module-pack.json -config custom-config.json
```

Data packs **cannot replace or remove core items**. The exact registry hash binds the selected item inventory, and the config digest binds the selectors. Keep packs frozen for a specific audit. A local extension does not confer authorization for testing.

## Engineering constraints and v0.1 boundaries

The audit engine is **not** an LLM itself, not a static analyzer, not a test runner by default, not an automatic GitHub PR reviewer, and not a code execution sandbox. It does not read repositories, publish PR comments, install MCP configuration, commit, push, merge or release anything automatically. It exports instructions, plans, machine ledger templates and mechanical validation for an independent human/agent process.

Config input is **strict JSON** for standard-library-only validation. The uploaded YAML scaffold is retained in `reference/` for historical traceability but is **not accepted as a runtime config**. Any selected assertion about a surface being absent is owner-provided metadata requiring external verification; the validator cannot establish absence just because a config file says so. SHA-256 format alone is not proof that evidence exists—use `-evidence-root` for real local byte checking. Release ZIP signing, a fully automated artifact integrity register, OAuth/GitHub posting, live CI retrieval, and semantic truth verification are not part of v0.1.

The current implementation uses **Go 1.23.2 stdlib** (`go.mod` has no external dependencies). More detail: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md), [docs/SECURITY.md](docs/SECURITY.md).

## Provenance and reference material

The initial 383 canonical item records were mechanically extracted from the **user-supplied** `UNIFIED_AUDIT_MASTER_PROMPT.md`, with 24 CORE and 11 language/domain inventories. Historical references and source-qualified aliases remain in `reference/` and in embedded registry JSON; ambiguous bare `PY-*` aliases are never used as primary IDs. The uploaded kit also includes a legacy hash index that refers to additional artifacts absent from the provided archive; this tool does not claim to have independently checked those absent files. The original Engram project is credited for deployment inspiration only.

## License

MIT for AuditGo source in this package; retain provenance and any separate terms applicable to user-provided reference material when redistributing it.
