module auditgo

go 1.23
