# Unified Audit Consolidation — Conflict and Deduplication Log v1.0

This is a **prompt-merge audit**, not an audit of the user's software. No target repository was inspected and no tests on a target were executed.

The six input nodes were supplied in the conversation. The user referred to a pre-existing file named `unified-audit-battery.scaffold.json.wrapped.yaml`, but its bytes were **not supplied**. The new scaffold here is an independent reconstruction of the specified behavior, not a comparison against that file's exact bytes.

| Conflict ID | Sources / disagreement | Deterministic resolution | Status |
|---|---|---|---|
| CF-01 | GO/GLOBAL/PYTHON/STACK offer different final disposition names (`GO_*`, `PYTHON_*`, `RED_TEAM_*` etc.) | One domain-neutral `PASS`, `PASS_WITH_HARDENING`, `ARCHITECTURE_SOUND_CONTRACT_OVERCLAIMED`, `HARDENING_REQUIRED`, `CORE_INVARIANT_FAILURE`; source names are historical aliases, not emitted values | RESOLVED |
| CF-02 | Go base disposition list orders PASS before more severe statuses but says choose "highest applicable"; PASS overlap with PASS_WITH_HARDENING | Evaluate the most adverse **supported** result first; PASS for no actionable hardening above LOW, PASS_WITH_HARDENING for real MEDIUM or actionable LOW; separate completeness gate | RESOLVED |
| CF-03 | Blocked mandatory item is called hardening-required in Go, but absence of evidence is not proof of high severity | `audit_completeness=EVIDENCE_INCOMPLETE`; preserve provisional `risk_disposition`; terminal `EVIDENCE_INCOMPLETE`, never fake HIGH risk | RESOLVED |
| CF-04 | Source prompts use 20/31/35/40 "independent adversaries" even in one-context environments | Distinct adversarial *perspectives* always; actual independence claimed only when isolated first-pass artifacts/agents exist. If required but unavailable => blocker | RESOLVED |
| CF-05 | Original compound chain minimums differ (5 generic, 10 Python, 15 Go/Stack) | Core aim at five grounded candidates; optional cross-module aim up to 15 candidates, record shortfall; never invent chains or run unsafe/absent surfaces to meet quota | RESOLVED |
| CF-06 | Aggressive Premature-Confidence mandates A–F grading; Go/stack audit says no numeric score and often no grade | Letter grades appear only when `PREMATURE_CONFIDENCE=true`, as non-disposition metadata; no numeric scores | RESOLVED |
| CF-07 | Go/Python variants require 34/27 distinct output headings; generic asks only concise report | Stable 17 report headings plus selected relevant module appendices. Findings appear once in Attack Matrix; auxiliary matrices reference IDs | RESOLVED |
| CF-08 | Original item coverage has RUN/ANALYZED/N/A/BLOCKED, but unified four module groups also include SKIPPED/OUT_OF_SCOPE | Module groups are `AUDITED`, `NOT_APPLICABLE`, `SKIPPED_BY_SELECTOR`, `OUT_OF_SCOPE`; item status extends legacy with `SKIPPED_BY_SELECTOR` and `OUT_OF_SCOPE`, retaining original four statuses | RESOLVED |
| CF-09 | Cross-source reuse of `PY-A`–`PY-BN` differs between Savant and Orchestrated Python prompts | Preserve source-qualified aliases `PY_SAVANT:PY-X` versus `PY_ORCH:PY-X`; bare `PY-X` invalid ambiguous reference; distinct semantics mapped via crosswalk | RESOLVED |
| CF-10 | Stack F8–F13 and Go/Python source contain overlapping safety, provenance, test, crash and runtime controls | Reuse one core obligation or a single domain item for conceptual duplicates; section/group alias expands to multiple items in machine crosswalk | RESOLVED |
| CF-11 | No evidence artifact is available for a hypothetical audit, but sources require SHA-256 for all CONFIRMED findings | SHA only for actual bytes; otherwise null+reason, cap chat-only claim below CONFIRMED and mark incomplete if required | RESOLVED |
| CF-12 | ZIP manifest + JSON checkpoint + final ZIP hash can create a cryptographic self-reference cycle | ZIP excludes the final JSON if JSON records ZIP digest; internal manifest lists all **other** ZIP members; external register hashes both frozen outputs and does not hash itself | RESOLVED |
| CF-13 | Source user-notes demand verifying Go permissions, starting a lifecycle, committing to a branch, writing to `~/Downloads` | Return-format requirements retained only as conditional delivery options. They confer no permission and do not force Go workflows on Python/spec/TS audits | RESOLVED |
| CF-14 | Some sources say reject/delete false positives; Go insists rejected IDs survive for traceability | Stage 3 can reject or downgrade, but archive rejected IDs, initial rating and reason | RESOLVED |
| CF-15 | Not-applicable, no evidence, explicitly out of scope, and selector false were conflated in older reports | Require proved absence for N/A; explicit exclusion for OUT_OF_SCOPE; false switch for SKIPPED; selected unknown surface stays AUDITED with item BLOCKED/ANALYZED as appropriate | RESOLVED |
| CF-16 | User asks only boolean switches while valid item verdicts require `true/false/null` invariant values | Strict booleans apply to **selectors** only. In verdict data `applicable` and `invariant_held` legitimately support `null` for unresolved; no coercion | RESOLVED |
| CF-17 | Destructive fixture language varies across ransomware, binary hijack, imports, SSRF and persistence cases | Union of all source safety restrictions; harmless disposable fixtures only, no third-party targets, no deployable payloads or real data destruction | RESOLVED |
| CF-18 | Go base assumes any selected item is assessed; other prompts let Stage 0 infer test availability | No audit-type auto-enable; select first; prove surface; record coverage for every item. Explicit module false cannot be promoted by discovery | RESOLVED |
| CF-19 | Conflicts between "artifact is sole authority" and conversation citations / URL-only evidence | Source artifacts and their bytes are canonical where available; URLs and chat are locators/context, not proof of bytes. Evidence includes hash or declared missing provenance | RESOLVED |
| CF-20 | Missing exact old-skeleton file bytes and missing actual target manifests prevent byte-equivalence claim | Do not claim the generated YAML is byte-compatible or vetted against omitted skeleton; retain this limitation until separately verified | OPEN EVIDENCE LIMITATION |

## Deduplication and classification

- **Core:** universal claims/contradictions, event ordering, recovery, authority/evidence identity, false-green, false positives, proofs/bytes and confidence boundaries (24 `CORE-*`). Legacy General A–R become CORE-001…CORE-018 in order.
- **Module:** Go/native/binary, Python semantics, agent tool authority, canonical hash/Merkle, SQL, wiki mirror, agent ledger, TS, Rust, build provenance and process recovery. A genuine language-specific legal behavior stays in a module rather than being watered down into generic prose.
- **Duplicate:** same semantic obligation reused in another prompt (source-qualified legacy alias points to the retained canonical item). Group aliases `STACK:F1`–`STACK:F13` expand to a set.
- **Conflict:** identity collisions, scoring/disposition differences, authority/packaging/independence claims resolved explicitly above. `PY-*` collisions are NOT treated as identical solely because they have the same letters.

## Exact legacy identifier coverage

| Source | Original stable IDs covered | Normalization |
|---|---:|---|
| Go/C-family/binary | 131 (`GO-A`…`GO-DZ`, plus `GO-EA`) | One domain-native canonical item per ID |
| Python Savant | 66 (`PY-A`…`PY-BN`) | One Python-native canonical item per ID |
| Python Orchestrated | 95 (`PY-A`…`PY-CQ`) | Semantically identical tests alias Python runtime; distinct items become agent-orchestration obligations |
| Stack detailed batteries | 105 (`CB/HX/HT/MK/SQ/WM/AG`, synthesized bullet IDs for TS/RS/BB/PX) | Domain-native canonical item per detailed entry |
| Stack section IDs | 13 (`F1`…`F13`) | Many-to-many section aliases; not single item findings |
| General LLM battery | 18 (`A`…`R`) | `CORE-001`…`CORE-018` |
| Premature Confidence | Original sections unnumbered | Synthetic anchors `CONFIDENCE:01`…`10`, `GRADE`; no invented claim that they were original IDs |

**Key caveat:** The 105 Stack detailed entries include **39 synthetic sub-item IDs** (`TS-01`…`TS-11`, `RS-01`…`RS-10`, `BB-01`…`BB-07`, `PX-01`…`PX-11`) for originally unnumbered bullet groups. Existing named `CB/HX/HT/MK/SQ/WM/AG` IDs remain verbatim. Crosswalk tracks provenance, not a claim that every compact summary preserves every illustrative example verbatim. The user-supplied source prompts remain the reference for full examples.

There are 63 bare-`PY-*` collision cases whose source-qualified references lead to different canonical items. The JSON crosswalk has the exact list. A parser should reject any bare `PY-X` item reference rather than silently pick one source.
